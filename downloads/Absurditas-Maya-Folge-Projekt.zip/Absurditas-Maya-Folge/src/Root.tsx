import React from 'react';
import {Composition} from 'remotion';
import {MayaEpisode} from './MayaEpisode';
import {episode} from './maya-full/episode';
export const Root:React.FC=()=> <Composition id="MayaEpisode" component={MayaEpisode}
    width={episode.width} height={episode.height} fps={episode.fps} durationInFrames={episode.durationInFrames}/>;
