import React from 'react';
import {P,Stars,Hills,Plants,Pyramid,Zero,Fireflies,span,lerp,hash,tint,camera} from '../maya/art';
import {House} from '../maya/CityAndPresent';
import {MayaPerson} from '../maya/Person';

export type Segment={id:string;chapter:string;scene:string;text:string;startFrame:number;endFrame:number;durationFrames:number;captions:readonly {start:number;end:number;text:string}[]};
export type Shot={u:number;d:number;p:number;global:number;seg:Segment};
export const cue=(a:Shot,fragment:string,fallback=0)=>{
 const cap=a.seg.captions.find(c=>c.text.includes(fragment));
 return cap?cap.start-a.seg.startFrame/30:fallback;
};
export const Txt:React.FC<{x:number;y:number;size?:number;fill?:string;anchor?:'start'|'middle'|'end';children:React.ReactNode;body?:boolean}>=({x,y,size=32,fill=P.cream,anchor='start',children,body=false})=><text x={x} y={y} fill={fill} textAnchor={anchor} fontFamily={body?'Body':'Display'} fontSize={size}>{children}</text>;

export const Backdrop:React.FC<{u:number;day?:number;hills?:boolean}>=({u,day=0,hills=true})=><>
 <rect width="1920" height="1080" fill="url(#m-sky)"/>
 <rect width="1920" height="1080" fill="url(#m-dawn)" opacity={day*.75}/>
 <Stars t={u} opacity={1-day*.85}/>
 <circle cx="1490" cy="250" r="240" fill="url(#m-aura)" opacity={.3+day*.5}/>
 {hills&&<Hills t={u} day={day}/>}
</>;

export const Ground:React.FC<{day?:number}>=({day=0})=><>
 <path d="M-500 1100Q650 650 1600 870Q2300 830 2600 1090V1700H-500Z" fill={tint('#205D6C','#75AC9B',day)}/>
 <path d="M-500 1320Q1000 870 2600 1120V1800H-500Z" fill={tint('#214D65','#4C8B87',day)}/>
</>;

export const MiniCity:React.FC<{x:number;y:number;scale?:number;warm?:number;u:number;pop?:number}>=({x,y,scale=1,warm=.6,u,pop=1})=><g transform={`translate(${x} ${y}) scale(${scale})`}>
 <path d="M-400 45L-70-100L440-30L360 120L-100 190Z" fill="#387D80"/>
 <path d="M-400 45V95L-100 235L360 165V120L-100 190Z" fill="#1D4A64"/>
 <Pyramid x={-20} y={75} size={.62} warmLevel={warm}/>
 <House x={-220} y={85} size={.63} warmLevel={warm}/><House x={260} y={65} size={.65} warmLevel={warm}/>
 <g opacity={pop}><MayaPerson x={90+u*4%130} y={125} t={u} size={.28} pose="walk" travel={u*4} color={P.coral}/><MayaPerson x={-100} y={151} t={u+1} size={.25} pose="carry" seed={1}/></g>
</g>;

export const Numeral:React.FC<{value:number;x:number;y:number;scale?:number;glow?:boolean;color?:string}>=({value,x,y,scale=1,glow=false,color=P.gold})=>{
 const bars=Math.floor(value/5),dots=value%5;
 return <g transform={`translate(${x} ${y}) scale(${scale})`}>
  {glow&&<ellipse rx="200" ry="155" fill="url(#m-aura)"/>}
  {value===0?<Zero size={.72} glow={glow}/>:<>
   {Array.from({length:dots},(_,i)=><circle key={i} cx={(i-(dots-1)/2)*45} cy={-bars*34-12} r="15" fill={color}/>)}
   {Array.from({length:bars},(_,i)=><rect key={i} x="-92" y={-i*34} width="184" height="22" rx="11" fill={color}/>)}
  </>}
 </g>;
};

export const Corn:React.FC<{x:number;y:number;size?:number;u:number;growth?:number;dry?:number}>=({x,y,size=1,u,growth=1,dry=0})=><g transform={`translate(${x} ${y}) scale(${size} ${size*Math.max(.03,growth)}) rotate(${Math.sin(u*1.1+x)*2})`}>
 <path d="M0 0Q12-115 1-231" fill="none" stroke={tint('#2E9B7E','#AA9566',dry)} strokeWidth="10"/>
 {[-1,1].map((side)=><g key={side}><path d={`M0-63Q${side*68}-155 ${side*96}-132Q${side*63}-68 0-63ZM0-129Q${side*50}-213 ${side*70}-189Q${side*42}-133 0-129Z`} fill={tint('#53BD91','#B49D63',dry)}/></g>)}
 <ellipse cx="15" cy="-143" rx="17" ry="43" fill={tint('#F6C86B','#B39866',dry)} transform="rotate(13 15 -143)"/>
 <path d="M3-164l23 2M2-150l27 2M1-136l28 2M4-122l22 1" stroke="#D6A66A" strokeWidth="3"/>
</g>;

export const Codex:React.FC<{x:number;y:number;scale?:number;open:number;u:number}>=({x,y,scale=1,open,u})=><g transform={`translate(${x} ${y}) scale(${scale})`}>
 {Array.from({length:6},(_,i)=>{
  const w=lerp(20,110,open),xx=(i-3)*w,tilt=i%2?13:-13;
  return <g key={i} transform={`translate(${xx} 0)`}>
   <path d={`M0 ${tilt}L${w} ${-tilt}V${205-tilt}L0 ${205+tilt}Z`} fill={i%2?'#E9B78D':P.cream}/>
   <path d={`M0 ${tilt}V${205+tilt}`} stroke="#BB8E7E" strokeWidth="2"/>
   <g opacity={span(u,.2+i*.12,1.4+i*.12)} fill="#76566C">
    {Array.from({length:6},(_,j)=><g key={j} transform={`translate(${w*.3+(j%2)*w*.33} ${45+Math.floor(j/2)*50})`}>
     <rect x="-10" y="-10" width="22" height="22" rx="7" fill="none" stroke="#9D6D76" strokeWidth="3"/>
     <circle r="4"/><path d="M-4 8h8" stroke="#76566C" strokeWidth="2"/>
    </g>)}
   </g>
  </g>;
 })}
</g>;

export const SceneFinish:React.FC<{u:number;plants?:boolean}>=({u,plants=true})=><>
 {plants&&<Plants t={u}/>}<Fireflies t={u} count={14} opacity={.35}/>
</>;
