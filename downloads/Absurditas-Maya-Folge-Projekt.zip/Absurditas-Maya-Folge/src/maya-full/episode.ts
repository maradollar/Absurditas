export const episode = {
  "title": "Die Maya: Eine kleine Form, eine große Geschichte",
  "fps": 30,
  "width": 1920,
  "height": 1080,
  "durationInFrames": 7864,
  "durationSeconds": 262.1333333333333,
  "voice": "Piper/Thorsten, selected voice A",
  "segments": [
    {
      "id": "hook",
      "chapter": "Die kleine Form",
      "scene": "hook",
      "text": "Dieses Zeichen sieht aus wie eine Muschel. Für die Maya konnte es null bedeuten. Ein Zeichen für nichts. Und trotzdem ein Schlüssel zu großen Zahlen.",
      "index": 0,
      "startFrame": 0,
      "endFrame": 280,
      "durationFrames": 280,
      "captions": [
        {
          "start": 0.18,
          "end": 2.2697959183673473,
          "text": "Dieses Zeichen sieht aus wie eine Muschel."
        },
        {
          "start": 2.439795918367347,
          "end": 4.599251700680272,
          "text": "Für die Maya konnte es null bedeuten."
        },
        {
          "start": 4.769251700680272,
          "end": 5.999909297052154,
          "text": "Ein Zeichen für nichts."
        },
        {
          "start": 6.169909297052154,
          "end": 8.735714285714286,
          "text": "Und trotzdem ein Schlüssel zu großen Zahlen."
        }
      ]
    },
    {
      "id": "promise",
      "chapter": "Die kleine Form",
      "scene": "promise",
      "text": "Aber hinter dieser kleinen Form steckt mehr als Mathematik: Städte, Könige, Bücher und Menschen, die den Himmel über Generationen beobachteten.",
      "index": 1,
      "startFrame": 280,
      "endFrame": 522,
      "durationFrames": 242,
      "captions": [
        {
          "start": 9.433333333333334,
          "end": 16.795691609977325,
          "text": "Aber hinter dieser kleinen Form steckt mehr als Mathematik: Städte, Könige, Bücher und Menschen, die den Himmel über Generationen beobachteten."
        }
      ]
    },
    {
      "id": "question",
      "chapter": "Die kleine Form",
      "scene": "question",
      "text": "Wie passte das zusammen? Und warum ist die Geschichte der Maya längst nicht zu Ende?",
      "index": 2,
      "startFrame": 522,
      "endFrame": 687,
      "durationFrames": 165,
      "captions": [
        {
          "start": 17.5,
          "end": 18.823537414965987,
          "text": "Wie passte das zusammen?"
        },
        {
          "start": 18.993537414965985,
          "end": 21.91362811791383,
          "text": "Und warum ist die Geschichte der Maya längst nicht zu Ende?"
        }
      ]
    },
    {
      "id": "region",
      "chapter": "Eine Welt aus Städten",
      "scene": "map",
      "text": "Wir reisen nach Mesoamerika: in den Süden des heutigen Mexiko und in Teile Mittelamerikas. Hier entwickelten Maya-Gesellschaften über viele Jahrhunderte unterschiedliche Städte und Traditionen.",
      "index": 3,
      "startFrame": 687,
      "endFrame": 1058,
      "durationFrames": 371,
      "captions": [
        {
          "start": 23.08,
          "end": 28.429433106575964,
          "text": "Wir reisen nach Mesoamerika: in den Süden des heutigen Mexiko und in Teile Mittelamerikas."
        },
        {
          "start": 28.59943310657596,
          "end": 34.67145124716553,
          "text": "Hier entwickelten Maya-Gesellschaften über viele Jahrhunderte unterschiedliche Städte und Traditionen."
        }
      ]
    },
    {
      "id": "cities",
      "chapter": "Eine Welt aus Städten",
      "scene": "cities",
      "text": "Es gab kein einziges Maya-Reich mit einer dauerhaften Hauptstadt. Städte wie Tikal, Palenque und Copán hatten eigene Herrscher. Sie handelten miteinander, schlossen Bündnisse und führten Kriege.",
      "index": 4,
      "startFrame": 1058,
      "endFrame": 1413,
      "durationFrames": 355,
      "captions": [
        {
          "start": 35.36666666666667,
          "end": 39.03541950113379,
          "text": "Es gab kein einziges Maya-Reich mit einer dauerhaften Hauptstadt."
        },
        {
          "start": 39.20541950113379,
          "end": 42.7602947845805,
          "text": "Städte wie Tikal, Palenque und Copán hatten eigene Herrscher."
        },
        {
          "start": 42.9302947845805,
          "end": 46.50557823129252,
          "text": "Sie handelten miteinander, schlossen Bündnisse und führten Kriege."
        }
      ]
    },
    {
      "id": "build",
      "chapter": "Eine Welt aus Städten",
      "scene": "build",
      "text": "Ihre Plätze, Tempel und Paläste waren politische Bühnen. Hinter den großen Bauten stand die Arbeit vieler Menschen: Steine mussten bearbeitet, Material transportiert und Nahrung erzeugt werden.",
      "index": 5,
      "startFrame": 1413,
      "endFrame": 1772,
      "durationFrames": 359,
      "captions": [
        {
          "start": 47.2,
          "end": 50.6249433106576,
          "text": "Ihre Plätze, Tempel und Paläste waren politische Bühnen."
        },
        {
          "start": 50.7949433106576,
          "end": 58.084693877551025,
          "text": "Hinter den großen Bauten stand die Arbeit vieler Menschen: Steine mussten bearbeitet, Material transportiert und Nahrung erzeugt werden."
        }
      ]
    },
    {
      "id": "farm",
      "chapter": "Alltag und Planung",
      "scene": "farm",
      "text": "Auf Feldern wuchs unter anderem Mais. Familien bewirtschafteten das Land, Handwerker stellten Waren her, und Händler verbanden Orte miteinander.",
      "index": 6,
      "startFrame": 1772,
      "endFrame": 2044,
      "durationFrames": 272,
      "captions": [
        {
          "start": 59.24666666666667,
          "end": 61.452562358276644,
          "text": "Auf Feldern wuchs unter anderem Mais."
        },
        {
          "start": 61.622562358276646,
          "end": 67.52378684807256,
          "text": "Familien bewirtschafteten das Land, Handwerker stellten Waren her, und Händler verbanden Orte miteinander."
        }
      ]
    },
    {
      "id": "water",
      "chapter": "Alltag und Planung",
      "scene": "water",
      "text": "In manchen Städten waren auch Wasserspeicher entscheidend. Wer mit Regen- und Trockenzeiten lebt, muss Vorräte und Arbeit gut planen. Beobachten, zählen und organisieren gehörten zusammen.",
      "index": 7,
      "startFrame": 2044,
      "endFrame": 2416,
      "durationFrames": 372,
      "captions": [
        {
          "start": 68.23333333333333,
          "end": 71.17065759637188,
          "text": "In manchen Städten waren auch Wasserspeicher entscheidend."
        },
        {
          "start": 71.34065759637188,
          "end": 75.97303854875284,
          "text": "Wer mit Regen- und Trockenzeiten lebt, muss Vorräte und Arbeit gut planen."
        },
        {
          "start": 76.14303854875284,
          "end": 79.55637188208617,
          "text": "Beobachten, zählen und organisieren gehörten zusammen."
        }
      ]
    },
    {
      "id": "digits",
      "chapter": "Rechnen mit nichts",
      "scene": "digits",
      "text": "Damit sind wir wieder bei der Muschel. Im Zahlensystem der Maya stand ein Punkt für eins. Ein Balken stand für fünf. Bis neunzehn ließen sich beide Zeichen kombinieren.",
      "index": 8,
      "startFrame": 2416,
      "endFrame": 2741,
      "durationFrames": 325,
      "captions": [
        {
          "start": 80.71333333333334,
          "end": 82.4548299319728,
          "text": "Damit sind wir wieder bei der Muschel."
        },
        {
          "start": 82.62482993197278,
          "end": 85.68986394557822,
          "text": "Im Zahlensystem der Maya stand ein Punkt für eins."
        },
        {
          "start": 85.85986394557823,
          "end": 87.25319727891156,
          "text": "Ein Balken stand für fünf."
        },
        {
          "start": 87.42319727891156,
          "end": 90.74365079365079,
          "text": "Bis neunzehn ließen sich beide Zeichen kombinieren."
        }
      ]
    },
    {
      "id": "twenty",
      "chapter": "Rechnen mit nichts",
      "scene": "twenty",
      "text": "Dann wechselte die Stelle. Wir bündeln beim Rechnen meistens Zehner. Die Maya nutzten ein System auf der Grundlage von zwanzig. Seine Stellen wurden übereinander angeordnet.",
      "index": 9,
      "startFrame": 2741,
      "endFrame": 3054,
      "durationFrames": 313,
      "captions": [
        {
          "start": 91.46666666666665,
          "end": 92.64807256235827,
          "text": "Dann wechselte die Stelle."
        },
        {
          "start": 92.81807256235827,
          "end": 94.96591836734693,
          "text": "Wir bündeln beim Rechnen meistens Zehner."
        },
        {
          "start": 95.13591836734693,
          "end": 98.43414965986393,
          "text": "Die Maya nutzten ein System auf der Grundlage von zwanzig."
        },
        {
          "start": 98.60414965986394,
          "end": 101.18464852607708,
          "text": "Seine Stellen wurden übereinander angeordnet."
        }
      ]
    },
    {
      "id": "zero",
      "chapter": "Rechnen mit nichts",
      "scene": "zero",
      "text": "Ein Punkt auf der nächsten Ebene konnte also zwanzig bedeuten. Darunter zeigte das Nullzeichen: Diese Stelle ist leer. Ohne diesen Platzhalter wären eins und zwanzig leicht zu verwechseln.",
      "index": 10,
      "startFrame": 3054,
      "endFrame": 3388,
      "durationFrames": 334,
      "captions": [
        {
          "start": 101.89999999999999,
          "end": 105.34816326530611,
          "text": "Ein Punkt auf der nächsten Ebene konnte also zwanzig bedeuten."
        },
        {
          "start": 105.51816326530611,
          "end": 108.32650793650792,
          "text": "Darunter zeigte das Nullzeichen: Diese Stelle ist leer."
        },
        {
          "start": 108.49650793650794,
          "end": 112.32780045351474,
          "text": "Ohne diesen Platzhalter wären eins und zwanzig leicht zu verwechseln."
        }
      ]
    },
    {
      "id": "idea",
      "chapter": "Rechnen mit nichts",
      "scene": "idea",
      "text": "Die Maya kannten damit eine eigenständige Darstellung der Null. Sie waren nicht die einzige Kultur, die solche Ideen entwickelte. Entscheidend ist, wie wirkungsvoll sie damit umgehen konnten.",
      "index": 11,
      "startFrame": 3388,
      "endFrame": 3750,
      "durationFrames": 362,
      "captions": [
        {
          "start": 113.03333333333333,
          "end": 116.66725623582767,
          "text": "Die Maya kannten damit eine eigenständige Darstellung der Null."
        },
        {
          "start": 116.83725623582767,
          "end": 120.36079365079365,
          "text": "Sie waren nicht die einzige Kultur, die solche Ideen entwickelte."
        },
        {
          "start": 120.53079365079365,
          "end": 123.99863945578231,
          "text": "Entscheidend ist, wie wirkungsvoll sie damit umgehen konnten."
        }
      ]
    },
    {
      "id": "books",
      "chapter": "Wissen wird sichtbar",
      "scene": "books",
      "text": "Wissen musste außerdem festgehalten werden. Die Maya schrieben auf Stein und in gefalteten Büchern. Ihre Schrift war viel mehr als eine Sammlung kleiner Bilder.",
      "index": 12,
      "startFrame": 3750,
      "endFrame": 4039,
      "durationFrames": 289,
      "captions": [
        {
          "start": 125.18,
          "end": 127.4439455782313,
          "text": "Wissen musste außerdem festgehalten werden."
        },
        {
          "start": 127.6139455782313,
          "end": 130.77185941043084,
          "text": "Die Maya schrieben auf Stein und in gefalteten Büchern."
        },
        {
          "start": 130.94185941043085,
          "end": 134.01850340136056,
          "text": "Ihre Schrift war viel mehr als eine Sammlung kleiner Bilder."
        }
      ]
    },
    {
      "id": "writing",
      "chapter": "Wissen wird sichtbar",
      "scene": "writing",
      "text": "Sie verband Zeichen für ganze Wörter mit Zeichen für Silben. So konnten Namen und Erzählungen aufgeschrieben werden. Ein geschnitztes Monument war deshalb nicht nur Dekoration.",
      "index": 13,
      "startFrame": 4039,
      "endFrame": 4356,
      "durationFrames": 317,
      "captions": [
        {
          "start": 134.73333333333332,
          "end": 137.89124716553286,
          "text": "Sie verband Zeichen für ganze Wörter mit Zeichen für Silben."
        },
        {
          "start": 138.06124716553288,
          "end": 141.0450113378685,
          "text": "So konnten Namen und Erzählungen aufgeschrieben werden."
        },
        {
          "start": 141.21501133786848,
          "end": 144.59351473922902,
          "text": "Ein geschnitztes Monument war deshalb nicht nur Dekoration."
        }
      ]
    },
    {
      "id": "power",
      "chapter": "Wissen wird sichtbar",
      "scene": "power",
      "text": "Herrscher ließen damit auch ihre Abstammung, wichtige Ereignisse und militärische Erfolge darstellen. Wissen erklärte die Welt. Und es half, Macht sichtbar zu machen.",
      "index": 14,
      "startFrame": 4356,
      "endFrame": 4684,
      "durationFrames": 328,
      "captions": [
        {
          "start": 145.29999999999998,
          "end": 151.05473922902493,
          "text": "Herrscher ließen damit auch ihre Abstammung, wichtige Ereignisse und militärische Erfolge darstellen."
        },
        {
          "start": 151.22473922902492,
          "end": 152.72242630385486,
          "text": "Wissen erklärte die Welt."
        },
        {
          "start": 152.89242630385488,
          "end": 155.13083900226758,
          "text": "Und es half, Macht sichtbar zu machen."
        }
      ]
    },
    {
      "id": "sky",
      "chapter": "Den Himmel beobachten",
      "scene": "sky",
      "text": "Auch der Himmel wurde zu einem wiederkehrenden Beobachtungsfeld. Sonne, Mond und besonders die Venus hinterließen Muster, die über lange Zeit verfolgt wurden.",
      "index": 15,
      "startFrame": 4684,
      "endFrame": 4978,
      "durationFrames": 294,
      "captions": [
        {
          "start": 156.31333333333333,
          "end": 159.76444444444445,
          "text": "Auch der Himmel wurde zu einem wiederkehrenden Beobachtungsfeld."
        },
        {
          "start": 159.93444444444444,
          "end": 165.33503401360542,
          "text": "Sonne, Mond und besonders die Venus hinterließen Muster, die über lange Zeit verfolgt wurden."
        }
      ]
    },
    {
      "id": "cycles",
      "chapter": "Den Himmel beobachten",
      "scene": "cycles",
      "text": "Die Maya nutzten unter anderem einen Kalender mit dreihundertfünfundsechzig Tagen und einen rituellen Zyklus mit zweihundertsechzig Tagen. Diese Zählungen konnten miteinander verbunden werden.",
      "index": 16,
      "startFrame": 4978,
      "endFrame": 5332,
      "durationFrames": 354,
      "captions": [
        {
          "start": 166.03333333333333,
          "end": 174.1487074829932,
          "text": "Die Maya nutzten unter anderem einen Kalender mit dreihundertfünfundsechzig Tagen und einen rituellen Zyklus mit zweihundertsechzig Tagen."
        },
        {
          "start": 174.3187074829932,
          "end": 177.13476190476192,
          "text": "Diese Zählungen konnten miteinander verbunden werden."
        }
      ]
    },
    {
      "id": "longcount",
      "chapter": "Den Himmel beobachten",
      "scene": "longcount",
      "text": "Dazu kam die Lange Zählung für ausgedehnte Zeiträume. Das waren unterschiedliche Werkzeuge für unterschiedliche Aufgaben. Keine magische Uhr, die das Ende der Welt vorhersagt.",
      "index": 17,
      "startFrame": 5332,
      "endFrame": 5675,
      "durationFrames": 343,
      "captions": [
        {
          "start": 177.83333333333331,
          "end": 181.00285714285712,
          "text": "Dazu kam die Lange Zählung für ausgedehnte Zeiträume."
        },
        {
          "start": 181.17285714285714,
          "end": 184.7951700680272,
          "text": "Das waren unterschiedliche Werkzeuge für unterschiedliche Aufgaben."
        },
        {
          "start": 184.9651700680272,
          "end": 188.16952380952378,
          "text": "Keine magische Uhr, die das Ende der Welt vorhersagt."
        }
      ]
    },
    {
      "id": "change",
      "chapter": "Wandel statt Verschwinden",
      "scene": "dry",
      "text": "Doch beeindruckendes Wissen macht eine Gesellschaft nicht unverwundbar. Zwischen dem achten und zehnten Jahrhundert verloren viele Städte im südlichen Tiefland an Bevölkerung und politischer Bedeutung.",
      "index": 18,
      "startFrame": 5675,
      "endFrame": 6032,
      "durationFrames": 357,
      "captions": [
        {
          "start": 189.34666666666666,
          "end": 193.10829931972788,
          "text": "Doch beeindruckendes Wissen macht eine Gesellschaft nicht unverwundbar."
        },
        {
          "start": 193.2782993197279,
          "end": 200.47140589569162,
          "text": "Zwischen dem achten und zehnten Jahrhundert verloren viele Städte im südlichen Tiefland an Bevölkerung und politischer Bedeutung."
        }
      ]
    },
    {
      "id": "causes",
      "chapter": "Wandel statt Verschwinden",
      "scene": "causes",
      "text": "Eine einzige Erklärung reicht dafür nicht. Forschende untersuchen das Zusammenspiel von Dürren, Konflikten, Umweltbedingungen und politischen Problemen. Nicht jede Stadt traf dieselbe Entwicklung zur selben Zeit.",
      "index": 19,
      "startFrame": 6032,
      "endFrame": 6415,
      "durationFrames": 383,
      "captions": [
        {
          "start": 201.16666666666666,
          "end": 203.518820861678,
          "text": "Eine einzige Erklärung reicht dafür nicht."
        },
        {
          "start": 203.688820861678,
          "end": 209.84378684807257,
          "text": "Forschende untersuchen das Zusammenspiel von Dürren, Konflikten, Umweltbedingungen und politischen Problemen."
        },
        {
          "start": 210.01378684807256,
          "end": 213.2192290249433,
          "text": "Nicht jede Stadt traf dieselbe Entwicklung zur selben Zeit."
        }
      ]
    },
    {
      "id": "continuity",
      "chapter": "Wandel statt Verschwinden",
      "scene": "continuity",
      "text": "Anderswo bestanden Maya-Zentren weiter. Später veränderte die spanische Kolonisierung das Leben erneut, oft mit Gewalt. Aus dem Wandel der Städte folgt aber nicht, dass ihre Menschen verschwanden.",
      "index": 20,
      "startFrame": 6415,
      "endFrame": 6793,
      "durationFrames": 378,
      "captions": [
        {
          "start": 213.93333333333334,
          "end": 216.6152380952381,
          "text": "Anderswo bestanden Maya-Zentren weiter."
        },
        {
          "start": 216.7852380952381,
          "end": 221.6846485260771,
          "text": "Später veränderte die spanische Kolonisierung das Leben erneut, oft mit Gewalt."
        },
        {
          "start": 221.8546485260771,
          "end": 225.4619501133787,
          "text": "Aus dem Wandel der Städte folgt aber nicht, dass ihre Menschen verschwanden."
        }
      ]
    },
    {
      "id": "today",
      "chapter": "Eine lebendige Geschichte",
      "scene": "today",
      "text": "Maya leben bis heute, sprechen verschiedene Maya-Sprachen und gestalten ihre Gegenwart. Als Lehrende, Landwirte, Kunstschaffende und in vielen anderen Berufen.",
      "index": 21,
      "startFrame": 6793,
      "endFrame": 7121,
      "durationFrames": 328,
      "captions": [
        {
          "start": 226.61333333333334,
          "end": 232.0110204081633,
          "text": "Maya leben bis heute, sprechen verschiedene Maya-Sprachen und gestalten ihre Gegenwart."
        },
        {
          "start": 232.18102040816328,
          "end": 236.7451927437642,
          "text": "Als Lehrende, Landwirte, Kunstschaffende und in vielen anderen Berufen."
        }
      ]
    },
    {
      "id": "work",
      "chapter": "Eine lebendige Geschichte",
      "scene": "work",
      "text": "Ihre Geschichte besteht deshalb nicht nur aus verlassenen Tempeln. Sie gehört auch Menschen, die lernen, arbeiten und Wissen weitergeben.",
      "index": 22,
      "startFrame": 7121,
      "endFrame": 7379,
      "durationFrames": 258,
      "captions": [
        {
          "start": 237.46666666666667,
          "end": 240.98448979591836,
          "text": "Ihre Geschichte besteht deshalb nicht nur aus verlassenen Tempeln."
        },
        {
          "start": 241.15448979591838,
          "end": 245.35839002267574,
          "text": "Sie gehört auch Menschen, die lernen, arbeiten und Wissen weitergeben."
        }
      ]
    },
    {
      "id": "legacy",
      "chapter": "Eine lebendige Geschichte",
      "scene": "legacy",
      "text": "Aus einer kleinen Muschel wurde für uns eine Reise durch eine große Ideenwelt. Die alten Städte erzählen von der Vergangenheit. Die Menschen erzählen weiter.",
      "index": 23,
      "startFrame": 7379,
      "endFrame": 7662,
      "durationFrames": 283,
      "captions": [
        {
          "start": 246.06666666666666,
          "end": 250.06049886621315,
          "text": "Aus einer kleinen Muschel wurde für uns eine Reise durch eine große Ideenwelt."
        },
        {
          "start": 250.23049886621317,
          "end": 252.92401360544218,
          "text": "Die alten Städte erzählen von der Vergangenheit."
        },
        {
          "start": 253.09401360544217,
          "end": 254.7774603174603,
          "text": "Die Menschen erzählen weiter."
        }
      ]
    },
    {
      "id": "end",
      "chapter": "Eine lebendige Geschichte",
      "scene": "end",
      "text": "Wenn du weitere überraschende Geschichten entdecken möchtest, abonniere Absurditas.",
      "index": 24,
      "startFrame": 7662,
      "endFrame": 7864,
      "durationFrames": 202,
      "captions": [
        {
          "start": 255.5,
          "end": 259.9501587301587,
          "text": "Wenn du weitere überraschende Geschichten entdecken möchtest, abonniere Absurditas."
        }
      ]
    }
  ],
  "chapters": [
    {
      "title": "Die kleine Form",
      "startFrame": 0,
      "endFrame": 687
    },
    {
      "title": "Eine Welt aus Städten",
      "startFrame": 687,
      "endFrame": 1772
    },
    {
      "title": "Alltag und Planung",
      "startFrame": 1772,
      "endFrame": 2416
    },
    {
      "title": "Rechnen mit nichts",
      "startFrame": 2416,
      "endFrame": 3750
    },
    {
      "title": "Wissen wird sichtbar",
      "startFrame": 3750,
      "endFrame": 4684
    },
    {
      "title": "Den Himmel beobachten",
      "startFrame": 4684,
      "endFrame": 5675
    },
    {
      "title": "Wandel statt Verschwinden",
      "startFrame": 5675,
      "endFrame": 6793
    },
    {
      "title": "Eine lebendige Geschichte",
      "startFrame": 6793,
      "endFrame": 7864
    }
  ]
} as const;
