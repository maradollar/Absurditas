import React from 'react';
import {interpolatePath} from '@remotion/paths';
import {P,Zero,Pyramid,Plants,Fireflies,span,lerp,camera} from '../maya/art';
import {MayaPerson} from '../maya/Person';
import {Backdrop,Ground,Numeral,Codex,SceneFinish,Txt,cue,Shot} from './common';

const circle='M-34 0C-34-19-19-34 0-34C19-34 34-19 34 0C34 19 19 34 0 34C-19 34-34 19-34 0Z';
const bar='M-150 0C-150-18-132-22-114-22H114C132-22 150-18 150 0C150 18 132 22 114 22H-114C-132 22-150 18-150 0Z';

export const Stone:React.FC<{x:number;y:number;scale?:number;children?:React.ReactNode}>=({x,y,scale=1,children})=><g transform={`translate(${x} ${y}) scale(${scale})`}>
 <ellipse cy="325" rx="330" ry="50" fill={P.deep} opacity=".3"/>
 <path d="M-247 302L-224-335L210-360L240 302Z" fill="#22586E"/>
 <path d="M210-360L279-398L310 259L240 302Z" fill="#173D54"/><path d="M-224-335L-153-383L279-398L210-360Z" fill="#4D9A98"/>
 <path d="M-202-308L189-330M-224 283H216" stroke="#68ABA7" strokeWidth="4" opacity=".5"/>
 {children}
</g>;

export const Digits:React.FC<Shot>=(a)=>{
 const {u,p}=a,one=cue(a,'Im Zahlensystem',2.5),five=cue(a,'Ein Balken',5.5),nineteen=cue(a,'Bis neunzehn',7.5);
 const q=span(u,five,five+.9),value=u<one?0:u<five?1:u<nineteen?5:Math.min(19,5+Math.floor(span(u,nineteen,nineteen+1.8)*14));
 return <>
  <Backdrop u={u} hills={false}/>
  <g transform={camera(1.04+p*.04,960,590)}>
   <Stone x={1170} y={565} scale={1.05}>
    {value===0?<Zero size={1.2} t={u}/>:u<nineteen?<g transform="scale(1.35)">
     {[-2,-1,1,2].map(i=><circle key={i} cx={i*67*(1-q)} cy="0" r={25} opacity={span(u,five-.35,five)*(1-q)} fill={P.gold}/>)}
     <path d={interpolatePath(q,circle,bar)} fill="url(#m-gold)"/>
    </g>:<Numeral value={value} x={0} y={-20} scale={1.4}/>}
    <Txt x={0} y={229} size={65} anchor="middle" fill={P.mint}>{value}</Txt>
   </Stone>
   <MayaPerson x={490} y={1000} size={1.2} t={5+u*.4} pose="count"/>
   <path d="M590 750Q800 420 1070 510" fill="none" stroke={P.jade} strokeWidth="2" strokeDasharray="3 13" opacity=".25"/>
  </g><SceneFinish u={u}/>
 </>;
};

export const Twenty:React.FC<Shot>=(a)=>{
 const {u,p,d}=a,base=cue(a,'Die Maya',4),stackAt=cue(a,'Seine Stellen',7);
 const bundle=span(u,base+.5,stackAt+1),stack=span(u,stackAt,stackAt+1.4);
 return <>
  <Backdrop u={u} hills={false}/><Ground day={.2}/>
  <g transform={camera(1.02,lerp(990,1110,p),600)}>
   <Stone x={1190} y={565} scale={1.04}>
    {Array.from({length:20},(_,i)=>{const angle=i/20*Math.PI*2;return <circle key={i} cx={Math.cos(angle)*170*(1-bundle)} cy={Math.sin(angle)*130*(1-bundle)+40-bundle*135} r={12} fill={P.gold} opacity={1-bundle}/>;})}
    <circle cx="0" cy={lerp(-95,-171,stack)} r={36} fill={P.gold} opacity={bundle}/>
    <Zero y={113} size={.88} opacity={bundle} t={u} gold={false}/>
    <path d="M-210-16H210" stroke="#4C8991" strokeWidth="3" opacity={stack}/>
   </Stone>
   <g opacity={1-span(u,base,base+1.3)}><circle cx="510" cy="400" r="133" fill="#23576D"/>{Array.from({length:10},(_,i)=>{const q=i/10*Math.PI*2;return <circle key={i} cx={510+Math.cos(q)*94} cy={400+Math.sin(q)*94} r="10" fill={P.jade}/>;})}<Txt x={510} y={421} size={57} anchor="middle">10</Txt></g>
   <MayaPerson x={450} y={1000} t={5+u*.35} size={1.12} pose="count" color={P.coral}/>
   <Txt x={1200} y={965} size={58} anchor="middle" fill={P.gold}>20</Txt>
  </g><SceneFinish u={u}/>
 </>;
};

export const ZeroPlace:React.FC<Shot>=(a)=>{
 const {u,p}=a,zero=cue(a,'Darunter',2.8),missing=cue(a,'Ohne',6.5);
 const focus=span(u,zero,zero+1.1),fade=span(u,missing,missing+1);
 return <>
  <Backdrop u={u} hills={false}/>
  <g transform={camera(1.03+p*.035,980,570)}>
   <Stone x={1260} y={560} scale={1}>
    <circle cy="-176" r="37" fill={P.gold}/>
    <Zero y={104} size={.94} t={u} gold={false} opacity={1-fade*.22}/>
    <ellipse cy="104" rx={150+focus*12} ry="95" fill="none" stroke={P.light} strokeWidth="3" opacity={focus*(.7-fade*.3)}/>
    <Txt x={0} y={245} anchor="middle" size={56}>20</Txt>
   </Stone>
   <g transform="translate(650 600)"><circle cy="0" r="37" fill={P.gold}/><Txt x={0} y={195} size={56} anchor="middle">1</Txt></g>
   <MayaPerson x={330} y={1010} size={1} t={5+u*.4} pose="count"/>
  </g><SceneFinish u={u}/>
 </>;
};

export const Idea:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} hills={false}/>
 <g transform={camera(1.02+p*.04,960,560)}>
  <circle cx="960" cy="520" r="335" fill="url(#m-jade-aura)"/>
  <path d="M565 545Q940 190 1370 540M565 545Q940 900 1370 540" stroke={P.jade} strokeWidth="3" strokeDasharray="3 16" fill="none" opacity=".4"/>
  <Zero x={570} y={535} size={1.25} t={u}/>
  <Txt x={1370} y={632} size={245} anchor="middle" fill={P.mint}>0</Txt>
  <MayaPerson x={430} y={1010} t={u+6} pose="hold" size={.98}/>
  <MayaPerson x={1480} y={1010} t={u+3} modern female pose="hold" size={.98} color={P.coral} seed={2}/>
  {Array.from({length:9},(_,i)=>{const q=(u*.05+i/9)%1;return <circle key={i} cx={lerp(570,1370,q)} cy={535-Math.sin(q*Math.PI)*260} r="5" fill={P.gold}/>;})}
 </g><SceneFinish u={u}/>
</>;

export const Books:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} day={.35}/><Ground day={.2}/>
 <g transform={camera(1.02+p*.11,lerp(950,1100,p),630)}>
  <Pyramid x={1570} y={750} size={.6}/>
  <path d="M680 875L1360 755L1730 934L1000 1140Z" fill="#68A9A3"/>
  <path d="M1000 1140V1220L1730 1005V934Z" fill="#245870"/>
  <path d="M1500 1000L1480 1290H1545L1570 980M1000 1100L980 1320H1030L1055 1080" fill="#21475B"/>
  <MayaPerson x={660} y={1050} t={u+2} pose="write" size={1.18} color={P.coral}/>
  <Zero x={790} y={867} size={.27} t={u} glow={false}/>
  <g transform="translate(1190 735) scale(1.05 .72)"><Codex x={0} y={0} open={span(u,.65,4.0)} u={u}/></g>
  <Fireflies t={u} count={9} x={900} y={500} w={600} h={350}/>
 </g><SceneFinish u={u}/>
</>;

export const Writing:React.FC<Shot>=(a)=>{
 const {u,p}=a;
 return <>
 <Backdrop u={u} hills={false}/>
 <g transform={camera(1.02,960,570)}>
  <Codex x={990} y={650} scale={1.2} open={1} u={u}/>
  <g transform={`translate(625 ${360-Math.sin(u*.4)*7})`}>
   <circle r="145" fill="#285F73"/>
   <path d="M-75 8Q-21-55 55 8Q-21 69-75 8ZM-74 8L-109-35V51Z" fill={P.coral}/><circle cx="30" cy="-2" r="8" fill={P.plum}/>
   <Txt x={0} y={212} size={31} anchor="middle">Wörter</Txt>
  </g>
  <g transform="translate(1335 360)">
   <circle r="145" fill="#47335E"/>
   {[0,1,2,3,4].map(i=><path key={i} d={`M${-60+i*30} ${-Math.sin(u*2+i)*22-35}v${70+Math.sin(u*2+i)*44}`} stroke={P.gold} strokeWidth="12" strokeLinecap="round"/>)}
   <Txt x={0} y={212} size={31} anchor="middle">Silben</Txt>
  </g>
  <path d="M630 540Q785 640 820 690M1335 540Q1220 640 1190 690" fill="none" stroke={P.jade} strokeWidth="3" strokeDasharray="4 14"/>
  <MayaPerson x={360} y={1040} t={u+4} size={1.1} pose="write"/>
 </g><Txt x={960} y={1030} size={21} anchor="middle" body>Prinzipdarstellung · keine Übersetzung historischer Schriftzeichen</Txt><SceneFinish u={u}/>
 </>;
};

export const Power:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} day={.2}/><Ground day={.1}/>
 <g transform={camera(1.02+p*.05,990,620)}>
  <Pyramid x={610} y={930} size={1.15} warmLevel={.3}/>
  <MayaPerson x={620} y={440} t={u+4} pose="count" size={.75} color={P.coral}/>
  <path d="M591 206l-12-43 29 13 14-30 15 30 23-17-7 47Z" fill={P.gold}/>
  <Stone x={1410} y={600} scale={.93}>
   <g transform="translate(0 -130)"><circle r="91" fill="#32747D"/><MayaPerson x={0} y={95} t={u} pose="hold" size={.51} color={P.coral}/></g>
   <path d="M0-32V38M0 38L-115 105M0 38L115 105" fill="none" stroke={P.gold} strokeWidth="4"/>
   {[-115,115].map((x,i)=><g key={x}><circle cx={x} cy="125" r="52" fill="#32747D"/><MayaPerson x={x} y={170} t={u+i} pose="hold" size={.27} seed={i}/></g>)}
   <path d="M-120 245H120M-70 269H70" stroke={P.jade} strokeWidth="7" strokeLinecap="round"/>
  </Stone>
  <MayaPerson x={970} y={1070} t={u} pose="hammer" size={1.0}/>
 </g><SceneFinish u={u}/>
</>;
