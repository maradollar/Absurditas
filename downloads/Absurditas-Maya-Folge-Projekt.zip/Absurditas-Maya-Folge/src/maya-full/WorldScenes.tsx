import React from 'react';
import {P,Pyramid,Zero,Stars,Fireflies,Plants,Leaf,span,lerp,hash,camera,tint} from '../maya/art';
import {MayaPerson} from '../maya/Person';
import {Temple} from '../maya/TempleAndNumbers';
import {House} from '../maya/CityAndPresent';
import {Backdrop,Ground,MiniCity,Corn,Codex,Numeral,SceneFinish,Txt,cue,Shot} from './common';
import {countries} from './geography';

export const Hook:React.FC<Shot>=(a)=>{
 const tt=lerp(0,4.88,span(a.u,0,a.d*.78));
 return <><Temple t={tt}/><g opacity={span(a.p,.72,.93)}><Fireflies t={a.u} count={18} x={700} y={300} w={900} h={500}/></g></>;
};

export const Promise:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} hills={false}/>
 <g transform={`translate(${-p*100} 0) scale(${1+p*.08})`}>
  {[[480,470],[1030,440],[1590,490]].map(([x,y],i)=><g key={i} transform={`translate(${x} ${y})`}>
   <circle r={235} fill={i===0?'#265A70':i===1?'#423151':'#182C50'}/>
   <circle r="238" fill="none" stroke={i===1?P.coral:P.gold} strokeWidth="4" strokeDasharray="410 85 20 45" transform={`rotate(${u*4-i*40})`}/>
   {i===0?<g transform="translate(0 110)"><MiniCity x={0} y={0} scale={.55} u={u}/></g>:i===1?<><Codex x={0} y={-110} scale={.68} open={span(u,.1,2.3)} u={u}/><MayaPerson x={-100} y={190} size={.63} t={u+4} pose="write"/></>:<><Stars t={u} opacity={.35}/><circle cx="60" cy="-90" r="41" fill={P.light}/><MayaPerson x={0} y={200} size={.87} t={18+u*.3} pose="look" female color={P.coral}/></>}
  </g>)}
  <path d="M480 780Q1030 900 1590 790" fill="none" stroke={P.jade} strokeWidth="3" strokeDasharray="3 16" opacity=".4"/>
 </g>
 <Zero x={970} y={930} size={.39} t={u}/><SceneFinish u={u}/>
</>;

export const Question:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} day={.15}/><Ground day={.4}/>
 <g transform={camera(1.05-p*.05,960,650)}>
  <Pyramid x={510} y={820} size={.8} warm/>
  <House x={1510} y={850} size={1.5} modern warm/>
  <MayaPerson x={700+p*28} y={1020} size={1.2} t={u+4} pose="count"/>
  <MayaPerson x={1250-p*24} y={1020} size={1.2} t={u+2} modern female pose="hold" color={P.coral} seed={2}/>
  <path d="M760 780Q960 650 1170 780" fill="none" stroke={P.gold} strokeWidth="3" strokeDasharray="3 13"/>
  <Zero x={960} y={690} size={.5} t={u}/>
 </g><SceneFinish u={u}/>
</>;

const point=(lon:number,lat:number)=>({x:300+(lon+96)*115,y:100+(24-lat)*80});
const sites=[{name:'Palenque',...point(-92.05,17.48)},{name:'Tikal',...point(-89.62,17.22)},{name:'Copán',...point(-89.14,14.84)}];
export const MapScene:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} hills={false}/>
 <g transform={camera(lerp(.98,1.08,p),1030,550)}>
  <g fill="none" stroke="#407F87" strokeWidth="1" opacity=".22">{Array.from({length:9},(_,i)=><path key={i} d={`M0 ${i*145}H1920M${i*250} 0V1080`}/>)}</g>
  {countries.map((c,i)=><g key={c.code}>
   <path d={c.path} transform="translate(0 18)" fill="#133A53"/>
   <path d={c.path} fill={tint('#2B6879','#65B6A8',i/6)} stroke="#88C8B4" strokeWidth="2.5"/>
  </g>)}
  <path d="M1030 700Q1190 450 1210 300" fill="none" stroke={P.gold} strokeWidth="110" opacity={.14*span(u,1,3)}/>
  <Txt x={660} y={400} size={37}>Mexikos Süden</Txt>
  <Txt x={860} y={930} size={27}>Guatemala</Txt><Txt x={1245} y={680} size={23}>Belize</Txt><Txt x={1350} y={890} size={25}>Honduras</Txt>
  {sites.map((s,i)=><g key={s.name} opacity={span(u,2+i*.6,3.2+i*.6)}>
   <circle cx={s.x} cy={s.y} r={18+Math.sin(u*1.5+i)*3} fill={P.gold} opacity=".18"/>
   <circle cx={s.x} cy={s.y} r="7" fill={P.light}/>
   <path d={`M${s.x} ${s.y}l${i===0?-70:60} -55`} stroke={P.gold} strokeWidth="2"/>
   <Txt x={s.x+(i===0?-80:68)} y={s.y-58} size={28} anchor={i===0?'end':'start'}>{s.name}</Txt>
  </g>)}
 </g>
 <g transform="translate(170 800)"><Pyramid x={0} y={0} size={.32}/></g>
 <Txt x={105} y={1010} size={21} body>Heutige Länder zur Orientierung · ausgewählte Orte</Txt>
 <Fireflies t={u} count={10} opacity={.2}/>
</>;

export const Cities:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} day={.2} hills={false}/>
 <g transform={camera(1.04,lerp(900,1040,p),560)}>
  <MiniCity x={400} y={520} scale={.9} u={u}/><MiniCity x={1435} y={460} scale={.85} u={u+2}/><MiniCity x={1030} y={900} scale={.8} u={u+4}/>
  <path d="M420 600Q920 250 1410 530M1430 550Q1450 850 1040 910M990 950Q590 890 420 650" fill="none" stroke={P.gold} strokeWidth="3" strokeDasharray="6 15" opacity=".5"/>
  {[0,1,2,3,4].map(i=>{const q=(u*.12+i*.2)%1;return <circle key={i} cx={lerp(480,1360,q)} cy={lerp(590,530,q)-Math.sin(q*Math.PI)*210} r="6" fill={i%2?P.jade:P.gold}/>;})}
  <Txt x={370} y={715} size={33} anchor="middle">Tikal</Txt><Txt x={1460} y={650} size={33} anchor="middle">Palenque</Txt><Txt x={1040} y={1060} size={33} anchor="middle">Copán</Txt>
 </g>
 <Txt x={100} y={98} size={24}>Drei Stadtbeispiele · Verbindungen schematisch</Txt><SceneFinish u={u}/>
</>;

export const Build:React.FC<Shot>=({u,d,p})=>{
 const grow=span(u,.5,d*.78),walk=u*27;
 return <>
 <Backdrop u={u} day={.8}/><Ground day={.65}/>
 <g transform={camera(1.03+p*.05,lerp(940,1040,p),625)}>
  <defs><clipPath id="full-build"><rect x="500" y={970-grow*650} width="950" height="700"/></clipPath></defs>
  <g clipPath="url(#full-build)"><Pyramid x={1070} y={945} size={1.25} warm/></g>
  <House x={150} y={900} size={1.2} warm/><House x={1710} y={910} size={1.1}/>
  {[0,1,2,3,4,5].map(i=><g key={i} transform={`translate(${780+i%3*90} ${1010-Math.floor(i/3)*53})`}><path d="M0 0L80-8L98-47L20-44Z" fill="#74A2A2"/><path d="M20-44L98-47L72-65L0-57Z" fill="#B2C3AA"/></g>)}
  <MayaPerson x={280+walk} y={1070} t={u} size={1.1} pose="carry" cargo="stone" travel={walk} color={P.coral}/>
  <MayaPerson x={1460} y={1052} t={u} size={1.05} pose="hammer" color={P.jade} seed={1}/>
  <path d="M1530 931L1660 916L1690 980L1540 1002Z" fill="#8CA9A0"/>
  {Array.from({length:12},(_,i)=>{const a=(u*1.5+i*.12)%1;return <circle key={i} cx={1540+Math.sin(i*7)*a*70} cy={930-a*70+a*a*100} r={2.5*(1-a)} fill={P.cream} opacity={(1-a)*.7}/>;})}
 </g><SceneFinish u={u}/>
 </>;
};

export const Farm:React.FC<Shot>=({u,d,p})=><>
 <Backdrop u={u} day={.85}/><Ground day={.8}/>
 <g transform={camera(1.03,lerp(900,1050,p),650)}>
  <House x={1510} y={800} size={1.25} warm/>
  <path d="M420 980L1160 730L1580 970L800 1240Z" fill="#876C70"/>
  {[0,1,2].map(row=><g key={row}>{Array.from({length:7},(_,i)=><Corn key={i} x={620+i*120+row*60} y={915+row*95} size={.65+row*.1} u={u+i} growth={.22+.78*span(u,.3+i*.16,4.5+i*.16)}/>)}</g>)}
  <MayaPerson x={320+u*13} y={1050} size={1.12} t={u} pose="plant" travel={u*13} color={P.coral}/>
  {Array.from({length:7},(_,i)=>{const q=(u*.75+i*.13)%1;return <circle key={i} cx={430+u*13+q*105} cy={900+q*q*160} r={3} fill={P.gold} opacity={1-q}/>;})}
  <MayaPerson x={1690-u*14} y={1040} size={.83} t={u} pose="carry" travel={u*14} dir={-1} female seed={1}/>
 </g><SceneFinish u={u}/>
</>;

export const Reservoir:React.FC<{u:number;level:number}>=({u,level})=>{
 const yy=lerp(920,760,level);
 return <g>
  <path d="M520 760L1240 680L1570 825L800 1000Z" fill="#72A7A1"/>
  <path d="M520 760V925L800 1110V1000Z" fill="#285C71"/><path d="M800 1000L1570 825V945L800 1110Z" fill="#1C495F"/>
  <path d="M595 780L1240 715L1480 826L815 959Z" fill="#173E58"/>
  <defs><clipPath id="reservoir-water"><path d="M595 780L1240 715L1480 826L815 959Z"/></clipPath></defs>
  <g clipPath="url(#reservoir-water)"><path d={`M500 ${yy}Q1000 ${yy-18} 1600 ${yy}V1100H500Z`} fill="url(#m-water)"/>
   {[0,1,2].map(i=><path key={i} d={`M${740+i*140} ${yy+35+i*15}q50-10 100 0`} stroke={P.mint} strokeWidth="3" fill="none" opacity=".4"/>)}</g>
  <path d="M0 640L530 763" stroke="#28566D" strokeWidth="32"/><path d="M0 630L530 753" stroke="#63AAA4" strokeWidth="20"/>
 </g>;
};
export const Water:React.FC<Shot>=({u,d,p})=><>
 <Backdrop u={u} day={.4}/><Ground day={.35}/>
 <House x={240} y={750} size={1.5}/><Pyramid x={1570} y={740} size={.5}/>
 <Reservoir u={u} level={.25+.7*span(u,1,d*.75)}/>
 <MayaPerson x={1530} y={970} size={1.05} t={u} pose="pour" dir={-1} color={P.coral}/>
 <MayaPerson x={330+u*15} y={990} size={.75} t={u} pose="carry" travel={u*15}/>
 <g stroke={P.jade} strokeWidth="3" opacity={.45*(1-span(u,d*.6,d*.9))}>{Array.from({length:40},(_,i)=>{const xx=180+hash(i)*1550,yy=(u*210+hash(i+5)*1000)%1020;return <path key={i} d={`M${xx} ${yy}l-9 26`}/>;})}</g>
 <path d={`M1430 812Q1400 842 1350 ${820+Math.sin(u*4)*4}`} stroke={P.jade} strokeWidth="4" fill="none"/>
 <SceneFinish u={u}/>
</>;
