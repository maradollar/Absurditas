import React from 'react';
import {P,Zero,Pyramid,Stars,Plants,Leaf,Fireflies,span,lerp,camera,tint} from '../maya/art';
import {MayaPerson} from '../maya/Person';
import {Present,House} from '../maya/CityAndPresent';
import {Backdrop,Ground,MiniCity,Corn,Codex,Numeral,SceneFinish,Txt,cue,Shot} from './common';
import {Reservoir} from './WorldScenes';
import {countries} from './geography';

export const SkyScene:React.FC<Shot>=({u,p})=>{
 const sunAngle=lerp(-2.6,-.7,p),vx=1260+Math.cos(u*.22)*260,vy=230+Math.sin(u*.22)*90;
 return <>
  <Backdrop u={u} day={.15*(1-p)}/>
  <path d="M-100 900Q920 700 2100 925V1400H-100Z" fill="#214A61"/>
  <Pyramid x={1230} y={1000} size={1.25}/>
  <circle cx={430+Math.cos(sunAngle)*220} cy={350+Math.sin(sunAngle)*180} r="59" fill={P.gold} opacity={1-span(p,.2,.5)}/>
  <circle cx="780" cy="310" r="34" fill={P.mint}/>
  <path d="M930 290Q1300 50 1680 370" stroke={P.jade} strokeWidth="2" strokeDasharray="3 15" fill="none" opacity=".35"/>
  <circle cx={vx} cy={vy} r="47" fill="url(#m-aura)"/><circle cx={vx} cy={vy} r="10" fill={P.light}/>
  <path d={`M${vx} ${vy+25}l36 39`} stroke={P.gold} strokeWidth="2"/><Txt x={vx+49} y={vy+76} size={28}>Venus</Txt>
  <MayaPerson x={480} y={1010} t={18+u*.28} size={1.2} pose="look" female color={P.coral}/>
  <MayaPerson x={1650} y={1060} t={u+2} size={.85} pose="write"/>
  <path d="M1610 949L1820 901L1880 967L1670 1020Z" fill="#5FA198"/>
  <Txt x={960} y={1030} size={21} anchor="middle" body>Himmelsbewegung schematisch</Txt><SceneFinish u={u}/>
 </>;
};

const Ring:React.FC<{x:number;y:number;r:number;value:number;u:number;color:string}>=({x,y,r,value,u,color})=><g transform={`translate(${x} ${y})`}>
 <circle r={r+38} fill={P.deep} opacity=".4"/><circle r={r} fill="none" stroke={color} strokeWidth="46" opacity=".23"/>
 <g transform={`rotate(${u*7200/value})`}>
  <circle r={r} fill="none" stroke={color} strokeWidth="3"/>
  {Array.from({length:26},(_,i)=>{const a=i/26*Math.PI*2;return <path key={i} d={`M${Math.cos(a)*(r-12)} ${Math.sin(a)*(r-12)}L${Math.cos(a)*(r+12)} ${Math.sin(a)*(r+12)}`} stroke={color} strokeWidth={i%5?3:7}/>;})}
  <circle cx={r} r="15" fill={P.light}/>
 </g>
 <Txt x={0} y={14} size={94} anchor="middle" fill={color}>{value}</Txt><Txt x={0} y={69} size={28} anchor="middle">Tage</Txt>
</g>;

export const Cycles:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} hills={false}/>
 <g transform={camera(1.02+p*.03,1050,530)}>
  <Ring x={760} y={475} r={235} value={260} u={u} color={P.gold}/>
  <Ring x={1320} y={475} r={235} value={365} u={u} color={P.jade}/>
  <path d="M1017 475H1063" stroke={P.cream} strokeWidth="4" strokeDasharray="3 9"/>
  <MayaPerson x={415} y={1020} t={5+u*.2} size={1.1} pose="count"/>
  <Codex x={1340} y={850} scale={.5} open={1} u={u}/>
 </g>
 <Txt x={1080} y={1040} size={21} anchor="middle" body>Zyklen schematisch</Txt><SceneFinish u={u}/>
</>;

export const LongCount:React.FC<Shot>=({u,p,d})=>{
 const q=span(u,0,d*.8),x=lerp(360,1590,q);
 return <>
 <Backdrop u={u} hills={false}/>
 <path d="M210 650C580 260 1120 920 1570 500Q1780 300 1540 190Q1300 100 1140 300" fill="none" stroke="#276E7C" strokeWidth="94"/>
 <path d="M210 650C580 260 1120 920 1570 500Q1780 300 1540 190Q1300 100 1140 300" fill="none" stroke={P.jade} strokeWidth="4" strokeDasharray="3 18"/>
 {Array.from({length:16},(_,i)=>{const xx=250+i*87,yy=560+Math.sin(i*.4)*120;return <circle key={i} cx={xx} cy={yy} r={8} fill={i/16<p?P.gold:'#347281'}/>;})}
 <g transform={`translate(${x} ${560+Math.sin(q*Math.PI*2)*100})`}><circle r="95" fill="url(#m-aura)"/><Zero size={.44} t={u}/></g>
 <g transform={`translate(1510 330) rotate(${u*20})`} opacity={span(p,.6,.85)}><circle r="115" fill="none" stroke={P.gold} strokeWidth="3" strokeDasharray="340 80"/><circle cx="115" r="10" fill={P.light}/></g>
 <MayaPerson x={500} y={1020} t={u+3} size={1.1} pose="write"/>
 <Codex x={1190} y={850} scale={.7} open={1} u={u}/>
 <Txt x={260} y={270} size={35}>Lange Zählung</Txt><SceneFinish u={u}/>
 </>;
};

export const Dry:React.FC<Shot>=({u,d,p})=>{
 const dry=span(u,2,d*.83);
 return <>
  <Backdrop u={u} day={.7}/><Ground day={.5}/>
  <Pyramid x={1410} y={740} size={.55} warmLevel={.7}/>
  <House x={160} y={780} size={1.2} warm/>
  <Reservoir u={u} level={lerp(.82,.12,dry)}/>
  <g transform="translate(80 1020)">{[0,1,2,3,4].map(i=><Corn key={i} x={i*82} y={i%2*30} size={.7} u={u} dry={dry}/>)}</g>
  <MayaPerson x={1730-u*25} y={980} t={u} size={.9} pose="carry" travel={u*25} dir={-1} color={P.coral}/>
  <MayaPerson x={570-u*20} y={1050} t={u} size={.9} pose="walk" travel={u*20} dir={-1}/>
  <path d="M660 1060l45-25 31 45 45-29M1110 1000l27 37 36-23" stroke="#816C74" strokeWidth="3" fill="none" opacity={dry*.65}/>
  <Txt x={960} y={115} size={29} anchor="middle">Südliches Tiefland · 8.–10. Jahrhundert</Txt><SceneFinish u={u}/>
 </>;
};

export const Causes:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} hills={false}/>
 {[[500,350,'Klima'],[1390,350,'Konflikte'],[500,780,'Umwelt'],[1390,780,'Politik']].map(([xx,yy,name],i)=>{
  const x=Number(xx),y=Number(yy),r=183;
  return <g key={i} transform={`translate(${x} ${y})`}>
   <defs><clipPath id={'cause-'+i}><circle r={r}/></clipPath></defs>
   <circle r={r+3} fill="none" stroke={i%2?P.coral:P.gold} strokeWidth="3"/>
   <g clipPath={'url(#cause-'+i+')'}>
    <circle r={r} fill={i%2?'#392E53':'#255B6C'}/>
    {i===0?<><circle cx="90" cy="-80" r="46" fill={P.gold}/>{[0,1,2].map(j=><Corn key={j} x={-70+j*75} y={175} size={.65} u={u} dry={.8}/> )}</>:i===1?<><MayaPerson x={-90} y={180} size={.8} t={5+u*.25} pose="count" color={P.coral}/><MayaPerson x={90} y={180} size={.8} t={6+u*.25} dir={-1} pose="count"/></>:i===2?<><Leaf x={-40} y={180} size={1.2} angle={-17}/><Leaf x={45} y={180} size={1.2} angle={25}/><path d="M-170 130Q0 40 170 130" stroke={P.jade} strokeWidth="26" fill="none" opacity=".35"/></>:<><Pyramid x={0} y={160} size={.6}/><MayaPerson x={0} y={178} size={.75} t={u} pose="hold" color={P.coral}/></>}
   </g>
   <Txt x={0} y={r+46} size={29} anchor="middle">{String(name)}</Txt>
  </g>;
 })}
 <path d="M700 350Q950 230 1190 350M700 780Q950 900 1190 780M500 550V585M1390 550V585M700 440L1190 690M700 690L1190 440" fill="none" stroke={P.jade} strokeWidth="3" strokeDasharray="3 15" opacity=".4"/>
 <Zero x={945} y={570} size={.36} t={u}/>
</>;

export const Continuity:React.FC<Shot>=(a)=>{
 const {u,p}=a,colonial=span(u,cue(a,'Später',3),cue(a,'Aus dem Wandel',8));
 return <>
  <Backdrop u={u} hills={false}/>
  <g transform={camera(1.02,1060,550)}>
   {countries.map(c=><path key={c.code} d={c.path} fill="#29677A" stroke="#82BDB2" strokeWidth="2"/>)}
   <g transform="translate(1080 285)"><circle r="160" fill="url(#m-jade-aura)"/><MiniCity x={0} y={100} scale={.38} u={u}/></g>
   <Txt x={1050} y={170} size={29} anchor="middle">Neue Zentren im Norden</Txt>
   <g opacity={.45}><MiniCity x={800} y={745} scale={.3} u={u} pop={.15}/><MiniCity x={1140} y={875} scale={.26} u={u} pop={.1}/></g>
   <path d={`M${-600+colonial*950} -300L${-100+colonial*950} 1300H-1000V-300Z`} fill={P.plum} opacity=".4"/>
  </g>
  <g opacity={span(u,a.d*.55,a.d*.8)}><MayaPerson x={415} y={1070} size={1.1} t={u+2} pose="carry"/><MayaPerson x={1545} y={1070} size={1.1} t={u} pose="hold" color={P.coral}/><path d="M520 940Q960 790 1460 940" stroke={P.gold} strokeWidth="3" fill="none" strokeDasharray="3 13"/></g>
  <SceneFinish u={u}/>
 </>;
};

export const Today:React.FC<Shot>=({u,d,p})=><>
 <Present t={23+p*6.6}/>
 <g opacity={span(u,2,3)*(1-span(p,.85,1))}>
  <path d="M805 560q-50-80 0-95h200q50 10 15 90l-45 4-20 25-8-26Z" fill={P.cream} opacity=".86"/>
  {[0,1,2,3,4].map(i=><path key={i} d={`M${850+i*25} ${489-Math.sin(u*2+i)*9}v${38+Math.sin(u*2+i)*18}`} stroke="#527F8B" strokeWidth="6" strokeLinecap="round"/>)}
 </g>
</>;

export const Classroom:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} day={.55}/>
 <path d="M-100 400L1940 280V1300H-100Z" fill="#689B98"/>
 <path d="M-100 880L1940 780V1400H-100Z" fill="#377C86"/>
 <path d="M120 790V400L440 380V775ZM1570 720V330L1840 315V700Z" fill="#204A62"/>
 <g transform={camera(1.02+p*.06,990,645)}>
  <path d="M800 330L1510 300V800L800 850Z" fill="#153F56" stroke="#9DB19B" strokeWidth="12"/>
  <Numeral value={0} x={1005} y={540} scale={.8} glow={false}/><Txt x={1320} y={605} size={146} anchor="middle" fill={P.mint}>0</Txt>
  <path d="M1140 575h65" stroke={P.gold} strokeWidth="4"/>
  <MayaPerson x={635} y={1050} size={1.2} t={5+u*.3} modern female pose="count" color={P.coral} seed={2}/>
  <MayaPerson x={1270} y={1010} size={.77} t={u} modern child pose="hold" color={P.jade}/>
  <MayaPerson x={1600} y={985} size={.75} t={u+1} modern child pose="hold" color={P.gold} seed={1}/>
  <path d="M1110 965L1650 905L1820 1000L1250 1088Z" fill="#92C8B6"/><path d="M1250 1088V1200L1820 1100V1000Z" fill="#2A586E"/>
 </g><SceneFinish u={u}/>
</>;

export const Legacy:React.FC<Shot>=({u,p})=><>
 <Backdrop u={u} day={.2}/><Ground day={.35}/>
 <Pyramid x={550} y={855} size={.85} warmLevel={.4}/><House x={1570} y={900} size={1.55} modern warm/>
 <MayaPerson x={620} y={1070} size={1.14} t={u+1} pose="write"/>
 <MayaPerson x={1320} y={1070} size={1.14} t={u+2} modern female pose="hold" color={P.coral} seed={2}/>
 <path d="M650 760Q950 220 1290 760" fill="none" stroke={P.gold} strokeWidth="3" strokeDasharray="4 14" opacity=".6"/>
 <Zero x={lerp(740,1180,p)} y={620-Math.sin(p*Math.PI)*110} size={.62} t={u}/>
 <SceneFinish u={u}/>
</>;

export const End:React.FC<Shot>=({u,p})=><>
 <Present t={24+p*6}/>
 <g opacity={span(u,.4,1.2)} transform={`translate(960 ${300+(1-span(u,.4,1.2))*25})`}>
  <Zero x={0} y={-84} size={.35} t={u}/>
  <Txt x={0} y={15} size={66} anchor="middle" fill={P.light}>ABSURDITAS</Txt>
  <Txt x={0} y={70} size={25} anchor="middle">Überraschende Geschichten. Verständlich erzählt.</Txt>
 </g>
</>;
