import React from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame} from 'remotion';
import {MayaDefs,P,span} from './maya/art';
import {episode} from './maya-full/episode';
import {Shot} from './maya-full/common';
import {Hook,Promise as PromiseScene,Question,MapScene,Cities,Build,Farm,Water} from './maya-full/WorldScenes';
import {Digits,Twenty,ZeroPlace,Idea,Books,Writing,Power} from './maya-full/KnowledgeScenes';
import {SkyScene,Cycles,LongCount,Dry,Causes,Continuity,Today,Classroom,Legacy,End} from './maya-full/TimeAndHistory';

const scenes:Record<string,React.FC<Shot>>={hook:Hook,promise:PromiseScene,question:Question,map:MapScene,cities:Cities,build:Build,farm:Farm,water:Water,digits:Digits,twenty:Twenty,zero:ZeroPlace,idea:Idea,books:Books,writing:Writing,power:Power,sky:SkyScene,cycles:Cycles,longcount:LongCount,dry:Dry,causes:Causes,continuity:Continuity,today:Today,work:Classroom,legacy:Legacy,end:End};

export const MayaEpisode:React.FC=()=>{
 const frame=useCurrentFrame(),global=frame/30;
 const index=Math.max(0,episode.segments.findIndex(a=>frame>=a.startFrame&&frame<a.endFrame));
 const seg=episode.segments[index],u=(frame-seg.startFrame)/30,d=seg.durationFrames/30;
 const Scene=scenes[seg.scene];
 const prev=index?episode.segments[index-1]:undefined;
 const chapter=prev&&prev.chapter!==seg.chapter;
 const transition=chapter&&u<.5;
 const Previous=prev?scenes[prev.scene]:undefined;
 return <AbsoluteFill style={{background:P.night}}>
  <style>{`@font-face{font-family:Display;src:url('${staticFile('display.ttf')}')}@font-face{font-family:Body;src:url('${staticFile('body.ttf')}')}`}</style>
  <Audio src={staticFile('maya-full-voice.wav')}/><Audio src={staticFile('maya-full-sound.wav')}/>
  <svg width="1920" height="1080" viewBox="0 0 1920 1080">
   <MayaDefs/>
   <defs><clipPath id="episode-iris"><circle cx="1080" cy="520" r={span(u,0,.5)*2350}/></clipPath></defs>
   {transition&&prev&&Previous&&<Previous seg={prev} u={prev.durationFrames/30+u} d={prev.durationFrames/30} p={1} global={global}/>}
   <g clipPath={transition?'url(#episode-iris)':undefined}><Scene seg={seg} u={u} d={d} p={Math.max(0,Math.min(1,u/d))} global={global}/></g>
   {transition&&<circle cx="1080" cy="520" r={span(u,0,.5)*2350+4} stroke={P.gold} strokeWidth="4" opacity={.5*(1-span(u,0,.5))} fill="none"/>}
  </svg>
 </AbsoluteFill>;
};
