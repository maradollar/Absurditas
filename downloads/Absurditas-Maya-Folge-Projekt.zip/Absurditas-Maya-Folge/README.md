# Absurditas · Die Maya

**Eine kleine Form, eine große Geschichte** – abgeschlossene Folge mit 25 Szenen,
acht Kapiteln, 1920 × 1080 Pixeln, 30 Bildern pro Sekunde und 4:22,13 Minuten Laufzeit.
Synthetische Sprecherstimme A, eigene 2D-Vektorillustrationen, Figurenbewegungen,
Formübergänge, Kamerafahrten, Musik und Geräusche.

## Projekt öffnen und rendern

Benötigt werden Node.js 22 oder neuer, npm, Chromium/Chrome und FFmpeg mit ffprobe.
Die Sprachaufnahme und der Soundtrack liegen fertig unter `public/` bei. Zum
Rendern werden keine kostenpflichtige KI-Schnittstelle, kein API-Schlüssel und
keine separat erzeugten Bilder benötigt.

Im entpackten Ordner `Absurditas-Maya-Folge`:

```bash
npm ci
npm run typecheck
npm run render
npm run check
```

Das Ergebnis liegt unter `output/Absurditas-Maya-Folge.mp4`. `npm run studio`
öffnet die Remotion-Zeitleiste; `npm run stills` rendert Kontrollbilder.

Der Produktionsrenderer nutzt standardmäßig `/usr/bin/chromium`. Auf einem anderen
System den tatsächlichen Browserpfad setzen, zum Beispiel unter macOS/Linux:

```bash
BROWSER_PATH="/Pfad/zu/Chrome" npm run render
```

In PowerShell zuerst `$env:BROWSER_PATH = 'C:\Pfad\zu\chrome.exe'` setzen.
Chromium muss in der verwendeten Umgebung Prozesse und lokale Sockets öffnen dürfen.
Auf der eingerichteten Cloud-Maschine wurde der Export mit Node.js 24, Chromium
und FFmpeg ausgeführt.

## Inhalte bearbeiten

| Datei | Zweck |
|---|---|
| `production/maya_full/story.json` und `SKRIPT.md` | Inhalt, Kapitel und vollständiger Sprechertext |
| `src/MayaEpisode.tsx` | Auswahl der Szenen und Übergänge |
| `src/maya-full/WorldScenes.tsx` | Geografie, Städte, Bauen, Anbau und Wasser |
| `src/maya-full/KnowledgeScenes.tsx` | Zahlen, Null, Bücher, Schrift und Macht |
| `src/maya-full/TimeAndHistory.tsx` | Himmel, Kalender, Wandel und Gegenwart |
| `src/maya-full/episode.ts` und `output/maya-full/episode.json` | Bildgenaue Zeiten und Satzanfänge |
| `src/maya/Person.tsx` | Gelenkfiguren, an den Weg gebundene Schritte, Gesten und Gegenstände |
| `src/maya/art.tsx` | Farben, Pflanzen, Licht, Architektur und wiederkehrendes Nullzeichen |
| `public/maya-full-voice.wav` | Gewählte Stimme A, kompletter Sprechertext |
| `public/maya-full-sound.wav` | Originale Musik und Geräusche |
| `output/maya-full/Absurditas-Maya.srt` | Separat importierbare deutsche Untertitel |
| `QUELLEN.md` | Inhaltliche Grundlagen und Grenzen der schematischen Bilder |

Eine Textänderung erzeugt nicht von allein eine neue Audioaufnahme. Neue Sätze
erfordern eine neue Stimme und Zeitplanung; vorhandene Szenen reagieren teilweise
auf hinterlegte Satzanfänge. Die Quellen sind vollständig editierbar, aber diese
Folge ist eine ausgearbeitete Produktion und keine universelle Themen-zu-Video-KI.

## Optionale lokale Audioerzeugung

Nur zum Neu-Erzeugen von Stimme oder Sound werden Python, NumPy, soundfile und
sherpa-onnx gebraucht. Die getesteten Versionen stehen in `requirements.txt`.
Das offizielle Modell ist hier kostenlos erhältlich:

<https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-de_DE-thorsten-high.tar.bz2>

Archiv entpacken und `MAYA_TTS_MODEL` auf dessen Modellordner setzen. Beispiel:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r production/maya_full/requirements.txt
export MAYA_TTS_MODEL="/Pfad/vits-piper-de_DE-thorsten-high"
npm run prepare:audio
npm run sound
npm run render
```

Der Schritt erzeugt die Zeitleiste, das Voice-WAV, die Satzuntertitel und die
TypeScript-Zeitdaten neu. Die Sprachsynthese ist satzweise zwischengespeichert;
für neue Sätze ist das Modell nötig. Die normalen Renderbefehle brauchen Python
und Modell nicht. Auf anderen Rechnern ist ein identischer Sprach-Samplewert
wegen der Modellberechnung nicht garantiert.

## Prüfen und wiederaufnehmen

Der Renderer speichert acht Kapitel separat und verbindet das Bild erst am Ende
mit dem durchgehenden Ton. Der abschließende Farbexport konvertiert Remotions
JPEG-Farbbereich tatsächlich in begrenztes BT.709 mit YUV 4:2:0; es werden nicht
nur Metadaten umetikettiert. Nach einer Unterbrechung übernimmt ein erneuter Aufruf
nur Kapitel mit passendem Quellen-Fingerabdruck und korrekter Bildanzahl. Quellcode-
Änderungen machen den Bildcache ungültig. `FORCE_RENDER=1 npm run render` erzwingt
einen vollständigen neuen Bildexport. Ein bis mehrere Kapitel lassen sich mit
`npm run render -- 2 3` auswählen; zusammengesetzt wird nur, wenn alle Kapitel zur
aktuellen Quelle passen.

`npm run check` prüft die tatsächliche MP4: Auflösung, Codec, Bildrate, Bildanzahl,
Bild-/Tondauer, vollständiges Dekodieren, unbeabsichtigte Schwarzsequenzen,
Tonpegel und Untertitel-Zuordnung. Die Messwerte stehen in
`output/maya-full/validation.json`. Bildkontrolle und technische Prüfungen sind
getrennt dokumentiert; eine automatische Prüfung ersetzt kein menschliches Urteil
über Aussprache, Dramaturgie oder historische Bilddetails.

Die Lizenzbedingungen der Werkzeuge stehen in `QUELLEN.md` und `licenses/`.
