# YouTube-Material

## Titel

Die Maya: Wie ein Zeichen für nichts eine große Geschichte erzählt

## Beschreibung

Eine kleine Muschel führt uns zu einer großen Ideenwelt: Wir besuchen die Städte
der Maya, entdecken ihr Zahlensystem mit der Null und schauen auf Schrift, Kalender
und das Leben der Menschen. Und wir klären, warum die Geschichte der Maya bis heute
weitergeht.

Eine animierte Geschichte von Absurditas. Eigene 2D-Illustrationen, Animationen,
Musik und Geräusche. Der Sprechertext wird von einer synthetischen Stimme gesprochen.
Die Bilder sind stilisierte Veranschaulichungen, keine archäologischen Rekonstruktionen.

Die fachlichen Grundlagen und Bildkonventionen sind im Projekt unter
`production/maya_full/QUELLEN.md` dokumentiert.

## Kapitel

Diese Zeitmarken gehören zur gelieferten 4:22-Minuten-Fassung:

```text
0:00 Die kleine Form
0:23 Eine Welt aus Städten
0:59 Alltag und Planung
1:21 Rechnen mit nichts
2:05 Wissen wird sichtbar
2:36 Den Himmel beobachten
3:09 Wandel statt Verschwinden
3:46 Eine lebendige Geschichte
```

## Untertitel

`Absurditas-Maya.srt` in YouTube Studio als deutsche Untertitel mit Zeitangaben
importieren. Die Datei enthält Satzzeiten aus der tatsächlich verwendeten
Sprachsynthese; die Animationen enthalten keinen dauerhaft eingebrannten Untertitel.
