# Quellen und Bildkonventionen

Stand: 3. November 2026. Der Film ist ein eigenständig formulierter Überblick.
Aus den Fachquellen wurden keine Bilder, Tonaufnahmen oder längeren Textpassagen übernommen.

| Aussage im Sprechertext | Grundlage |
|---|---|
| Maya-Gesellschaften in Mesoamerika; verschiedene Städte statt einer dauerhaften gemeinsamen Hauptstadt; Tikal, Palenque und Copán; Herrscher, Handel, Bündnisse und Kriege | OpenStax, *World History*, „Early Cultures and Civilizations in the Americas“, Unterabschnitt „Maya Culture“. [Offizielle Textquelle](https://github.com/openstax/osbooks-world-history/blob/main/modules/m00115/index.cnxml). Abschnitt vollständig gelesen. |
| Maisanbau, Wasserverfügbarkeit, städtische Bauten, Arbeitsorganisation; Monumente als politische Darstellung | Derselbe Abschnitt; die Szenen verdichten die beschriebenen Tätigkeiten und stellen keinen bestimmten dokumentierten Arbeitstag dar. |
| Punkt = 1, Balken = 5, Kombination bis 19, vertikale Stellenwerte mit Basis 20, Null als Platzhalter | OpenStax, *Contemporary Mathematics*, „Early Numeration Systems“. [Offizielle Textquelle](https://github.com/openstax/osbooks-contemporary-mathematics/blob/main/modules/m00053/index.cnxml). Mathematischer Abschnitt geprüft. Das allgemeine Zahlensystem wird vom Kalender getrennt erklärt: Kalendereinheiten bilden keine reine Folge von Zwanzigerpotenzen. |
| Schrift zur Aufzeichnung von Ereignissen, Abstammung und Herrschaft | OpenStax „Maya Culture“, Beschreibung der Schrift und ihrer politischen Verwendung. Die Unterscheidung von Wort- und Silbenzeichen entspricht dem etablierten logosyllabischen Schriftmodell. |
| 260- und 365-Tage-Zyklen; längere Zeitrechnung | OpenStax „Maya Culture“ nennt beide Zyklen und ihre Verbindung. Die „Lange Zählung“ wird als zusätzliche Datierungsmethode behandelt, ohne eine Weltuntergangsvorhersage zu behaupten. |
| Wandel vieler südlicher Städte im späten ersten Jahrtausend; mehrere zusammenwirkende Ursachen; Weiterentwicklung im Norden | OpenStax „Maya Culture“, Schlussabsätze. Zeitraum und Ursachen bleiben bewusst als regional unterschiedliche Entwicklung formuliert. |
| Maya-Gesellschaften bestehen bis heute; mehrere Maya-Sprachen | Allgemein gesicherte Kontinuität, ohne pauschale Bevölkerungszahl oder Behauptung, heutige Kulturen seien unverändert. Weiterführend: Smithsonian National Museum of the American Indian, [Living Maya Time](https://maya.nmai.si.edu/). Die Museumsseite war aus dieser Umgebung nicht abrufbar; sie wird hier als weiterführende Anlaufstelle, nicht als hier gelesene Quelle geführt. |

Die gesichtete OpenStax-Geschichtsquelle fasst große Zeiträume zusammen. Aussagen,
die dort nicht im Detail belegt werden, etwa die genauen heutigen Berufsbeispiele,
sind illustrative Beispiele und keine Biografien bestimmter Personen. Der Film erhebt
keinen Anspruch auf eine vollständige Geschichte aller Maya-Gesellschaften.

## Landkarte und Abstraktion

Die heutige Ländergeometrie stammt aus dem öffentlichen Natural-Earth-Datensatz,
[110m Admin 0 countries](https://github.com/nvkelso/natural-earth-vector/blob/master/geojson/ne_110m_admin_0_countries.geojson).
Natural Earth stellt seine Kartendaten als [Public Domain](https://www.naturalearthdata.com/about/terms-of-use/) bereit.
Die modernen Ländergrenzen dienen der Orientierung; sie bilden keine historischen
Reichsgrenzen ab. Die Ortsmarkierungen sind angenähert.

Gebäude, Kleidung, Figuren, Herrscherinsignien und Bücher sind stilisierte eigene
Illustrationen. Die drei Stadtdioramen sind keine Rekonstruktionen der tatsächlichen
Stadtgrundrisse. Die Linien zwischen ihnen bezeichnen Beziehungen, keine nachgewiesenen
Verkehrsrouten. Die wiederkehrenden Schriftformen im Buch sind dekorative Formen;
die Szene zu Wörtern und Silben erklärt ein Prinzip und behauptet keine Übersetzung.
Die Himmelsbahnen und Kalenderringe sind schematisch, nicht astronomisch maßstabgetreu.

## Ton, Schrift und Werkzeuge

- Sprecher: synthetische Stimme A, offizielles Piper/Thorsten-Modell über sherpa-onnx;
  kein Klon des Referenzsprechers. Die mitgelieferte Modellkarte nennt den
  [Thorsten-Voice-Datensatz](https://github.com/thorstenMueller/Thorsten-Voice), CC0.
- Musik, Übergangsgeräusche und Foley wurden für dieses Projekt mathematisch erzeugt.
  Keine fremden Musikaufnahmen oder Soundbibliotheken.
- Schriften: DejaVu; Lizenz liegt unter `public/FONT-LICENSE.txt` bei.
- Remotion 4.0.540: beigelegte Lizenz unter `licenses/REMOTION.md`.
  Einzelpersonen und Unternehmen mit bis zu drei Beschäftigten können nach dieser
  Lizenz auch kommerzielle Videos kostenlos erstellen. Größere Unternehmen haben
  andere Bedingungen. Remotion ist deshalb nicht pauschal als frei von Bedingungen
  für jede Unternehmensgröße zu verstehen.
- Die hochgeladene Referenz wurde zur Gestaltung untersucht. Ihre Bild- und Toninhalte
  gehören nicht zum gelieferten Film oder Projektarchiv.
