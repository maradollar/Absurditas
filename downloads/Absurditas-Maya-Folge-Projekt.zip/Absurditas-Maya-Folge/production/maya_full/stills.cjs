const {bundle}=require('@remotion/bundler');
const {selectComposition,renderStill,openBrowser}=require('@remotion/renderer');
const path=require('path');const fs=require('fs');
(async()=>{
 const episode=JSON.parse(fs.readFileSync('output/maya-full/episode.json','utf8'));
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts')});
 const browserExecutable=process.env.BROWSER_PATH||'/usr/bin/chromium';
 const browser=await openBrowser('chrome',{browserExecutable});
 try{
  const composition=await selectComposition({serveUrl,id:'MayaEpisode',puppeteerInstance:browser});
  const args=process.argv.slice(2).map(Number);
  const frames=args.length?args:episode.segments.map(s=>s.startFrame+Math.floor(s.durationFrames*.55));
  fs.mkdirSync('output/maya-full/stills',{recursive:true});
  for(const frame of frames){
   await renderStill({serveUrl,composition,puppeteerInstance:browser,frame,output:`output/maya-full/stills/frame-${String(frame).padStart(5,'0')}.png`});
   console.log('Rendered',frame,episode.segments.find(s=>frame>=s.startFrame&&frame<s.endFrame)?.id);
  }
 }finally{await browser.close({silent:true});}
})().catch(e=>{console.error(e);process.exitCode=1;});
