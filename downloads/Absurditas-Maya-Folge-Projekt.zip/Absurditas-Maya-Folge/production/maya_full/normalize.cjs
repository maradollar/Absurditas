// Remotion 4's default JPEG pipeline encodes full-range BT.601. Convert real
// sample values to limited-range BT.709 for a conventional, well-tagged HD MP4.
// Keep this assembly step separate from the expensive picture render cache.
const fs=require('fs');const cp=require('child_process');const path=require('path');
const file=path.resolve('output/Absurditas-Maya-Folge.mp4');
const info=JSON.parse(cp.execFileSync('ffprobe',['-v','error','-select_streams','v:0',
 '-show_entries','stream=pix_fmt,color_range,color_space,color_primaries,color_transfer','-of','json',file],{encoding:'utf8'})).streams[0];
const tags='h264_metadata=video_full_range_flag=0:colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1';
if(info.pix_fmt==='yuv420p'&&info.color_range==='tv'&&info.color_space==='bt709'){
 if(info.color_primaries!=='bt709'||info.color_transfer!=='bt709'){
  const temp=file.replace(/\.mp4$/,'.tagged.mp4');
  cp.execFileSync('ffmpeg',['-v','error','-y','-i',file,'-map','0','-c','copy','-bsf:v',tags,'-movflags','+faststart',temp],{stdio:'inherit'});
  fs.renameSync(temp,file);
  console.log('Completed HD color metadata without re-encoding.');
 }else console.log('HD color format already normalized.');
}else{
 const matrices={bt470bg:'bt601',smpte170m:'bt601',bt709:'bt709'};
 const matrix=matrices[info.color_space];
 if(!matrix||!['pc','tv'].includes(info.color_range))throw new Error('Unknown input color metadata: '+JSON.stringify(info));
 const temp=file.replace(/\.mp4$/,'.normalizing.mp4');
 cp.execFileSync('ffmpeg',['-v','error','-y','-i',file,
  '-map','0:v:0','-map','0:a:0','-vf',`scale=in_range=${info.color_range}:out_range=tv:in_color_matrix=${matrix}:out_color_matrix=bt709,format=yuv420p,setsar=1`,
  '-c:v','libx264','-preset','fast','-b:v','2500k','-maxrate','2800k','-bufsize','5600k',
  '-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709',
  '-r','30','-fps_mode','cfr','-video_track_timescale','90000','-bsf:v',tags,'-c:a','copy','-map_metadata','0','-movflags','+faststart',temp],{stdio:'inherit'});
 fs.copyFileSync(file,path.resolve('output/maya-full/render/master-full-range.mp4'));
 fs.renameSync(temp,file);
 console.log('Normalized HD delivery:',file);
}
