"""Build cached voice-A narration, captions and a frame-exact episode timeline."""
from pathlib import Path
import hashlib,json,math,os,re,subprocess,textwrap
import numpy as np
import sherpa_onnx
import soundfile as sf

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'output/maya-full'
CACHE=OUT/'speech-cache'
MODEL=Path(os.environ.get('MAYA_TTS_MODEL','/workspace/.models/vits-piper-de_DE-thorsten-high'))
FPS=30


def stamp(t):
    ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000)
    return f'{h:02}:{m:02}:{s:02},{ms:03}'


def main():
    CACHE.mkdir(parents=True,exist_ok=True)
    (ROOT/'src/maya-full').mkdir(parents=True,exist_ok=True)
    story=json.loads((ROOT/'production/maya_full/story.json').read_text())
    config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(
        vits=sherpa_onnx.OfflineTtsVitsModelConfig(
            model=str(MODEL/'de_DE-thorsten-high.onnx'),tokens=str(MODEL/'tokens.txt'),
            data_dir=str(MODEL/'espeak-ng-data')),num_threads=4),max_num_sentences=1)
    assert config.validate()
    tts=sherpa_onnx.OfflineTts(config)
    sr=tts.sample_rate
    pieces=[];segments=[];captions=[];frame=0
    for index,item in enumerate(story):
        start=frame
        is_chapter_start=index==0 or item['chapter']!=story[index-1]['chapter']
        lead=.18 if is_chapter_start else .10
        blocks=[np.zeros(round(lead*sr),dtype=np.float32)]
        elapsed=lead;local_captions=[]
        sentences=[x.strip() for x in re.split(r'(?<=[.!?])\s+',item['text']) if x.strip()]
        for sentence in sentences:
            key=hashlib.sha256(('thorsten-high|0.84|v1|'+sentence).encode()).hexdigest()[:20]
            cache=CACHE/(key+'.wav')
            if cache.exists():
                audio,rate=sf.read(cache,dtype='float32');assert rate==sr
            else:
                generated=tts.generate(sentence,sid=0,speed=.84)
                audio=np.asarray(generated.samples,dtype=np.float32)
                assert len(audio)>.15*sr and np.all(np.isfinite(audio))
                sf.write(cache,audio,sr)
            duration=len(audio)/sr
            cap={'start':start/FPS+elapsed,'end':start/FPS+elapsed+duration,'text':sentence}
            local_captions.append(cap);captions.append(cap)
            blocks.extend([audio,np.zeros(round(.17*sr),dtype=np.float32)])
            elapsed+=duration+.17
        chapter_end=index==len(story)-1 or item['chapter']!=story[index+1]['chapter']
        tail=2.0 if index==len(story)-1 else .8 if chapter_end else .42
        frames=math.ceil((elapsed+tail)*FPS)
        data=np.concatenate(blocks)
        target_samples=round(frames/FPS*sr)
        assert len(data)<=target_samples
        data=np.pad(data,(0,target_samples-len(data)))
        pieces.append(data)
        frame+=frames
        segment={**item,'index':index,'startFrame':start,'endFrame':frame,
                 'durationFrames':frames,'captions':local_captions}
        segments.append(segment)
        print(f'{index+1:02}/{len(story)} {item["id"]}: {frames/FPS:.2f}s, total {frame/FPS:.2f}s',flush=True)
    assert 180<frame/FPS<330, f'Unexpected episode length: {frame/FPS}'
    raw=np.concatenate(pieces)
    sf.write(OUT/'voice-raw.wav',raw,sr)
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(OUT/'voice-raw.wav'),
                    '-af','loudnorm=I=-16:TP=-2:LRA=8','-ar','48000','-ac','2',
                    str(ROOT/'public/maya-full-voice.wav')],check=True)
    chapters=[]
    for item in segments:
        if not chapters or chapters[-1]['title']!=item['chapter']:
            chapters.append({'title':item['chapter'],'startFrame':item['startFrame'],'endFrame':item['endFrame']})
        else:chapters[-1]['endFrame']=item['endFrame']
    episode={'title':'Die Maya: Eine kleine Form, eine große Geschichte','fps':FPS,
             'width':1920,'height':1080,'durationInFrames':frame,'durationSeconds':frame/FPS,
             'voice':'Piper/Thorsten, selected voice A','segments':segments,'chapters':chapters}
    (OUT/'episode.json').write_text(json.dumps(episode,ensure_ascii=False,indent=2))
    (ROOT/'src/maya-full/episode.ts').write_text('export const episode = '+json.dumps(episode,ensure_ascii=False,indent=2)+' as const;\n')
    srt='\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n'+
                     '\n'.join(textwrap.wrap(c['text'],width=48)) for i,c in enumerate(captions))
    (OUT/'Absurditas-Maya.srt').write_text(srt+'\n')
    md=['# Die Maya: Eine kleine Form, eine große Geschichte','',
        'Vollständiger Sprechertext · Stimme A · ungefähr vier Minuten','']
    previous=None
    for item in story:
        if item['chapter']!=previous:
            md.extend(['## '+item['chapter'],'']);previous=item['chapter']
        md.extend([item['text'],''])
    (ROOT/'production/maya_full/SKRIPT.md').write_text('\n'.join(md))
    print('READY:',frame,'frames,',round(frame/FPS,2),'seconds',flush=True)


if __name__=='__main__':main()
