"""Check the delivered movie itself, including full decoding and audio levels."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,re,subprocess,sys

ROOT=Path(__file__).resolve().parents[2]
EP=json.loads((ROOT/'output/maya-full/episode.json').read_text())
FILE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'output/Absurditas-Maya-Folge.mp4'
FPS=EP['fps'];DURATION=EP['durationInFrames']/FPS


def run(args):
    result=subprocess.run(args,text=True,capture_output=True)
    if result.returncode:raise RuntimeError(result.stderr[-3000:])
    return result


def main():
    info=json.loads(run(['ffprobe','-v','error','-show_streams',
                         '-show_format','-of','json',str(FILE)]).stdout)
    video=next(s for s in info['streams'] if s['codec_type']=='video')
    audio=next(s for s in info['streams'] if s['codec_type']=='audio')
    assert (video['width'],video['height'])==(1920,1080)
    assert video['codec_name']=='h264' and video['pix_fmt']=='yuv420p'
    assert video['color_space']=='bt709' and video['color_range']=='tv'
    assert video['color_primaries']=='bt709' and video['color_transfer']=='bt709'
    assert Fraction(video['avg_frame_rate'])==FPS
    assert Fraction(video['r_frame_rate'])==FPS
    assert int(video['nb_frames'])==EP['durationInFrames']
    assert abs(float(video['duration'])-DURATION)<.01
    assert abs(float(audio['duration'])-DURATION)<.1
    assert audio['codec_name']=='aac' and int(audio['sample_rate'])==48000 and audio['channels']==2
    assert float(video.get('start_time',0))==0
    previous=0;captions=[]
    for s in EP['segments']:
        assert s['startFrame']==previous and s['endFrame']>previous
        assert s['endFrame']-s['startFrame']==s['durationFrames']
        previous=s['endFrame']
        for c in s['captions']:
            assert s['startFrame']/FPS<=c['start']<c['end']<=s['endFrame']/FPS
            if captions:assert c['start']>=captions[-1]['end']
            captions.append(c)
    assert previous==EP['durationInFrames']
    blocks=(ROOT/'output/maya-full/Absurditas-Maya.srt').read_text().strip().split('\n\n')
    assert len(blocks)==len(captions)
    for i,(block,caption) in enumerate(zip(blocks,captions)):
        lines=block.splitlines();assert int(lines[0])==i+1
        assert ' '.join(lines[2:])==caption['text']
    result=run(['ffmpeg','-hide_banner','-nostats','-i',str(FILE),
                '-filter_complex','[0:v:0]blackdetect=d=0.1:pix_th=0.02:pic_th=0.98[v];'
                '[0:a:0]loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json[a]',
                '-map','[v]','-map','[a]','-fps_mode','passthrough','-progress','pipe:1','-f','null','-'])
    log=result.stderr
    decoded=int(re.findall(r'^frame=\s*(\d+)\s*$',result.stdout,re.M)[-1])
    assert decoded==EP['durationInFrames'],decoded
    black=re.findall(r'black_start:([\d.]+) black_end:([\d.]+) black_duration:([\d.]+)',log)
    errors=[line for line in log.splitlines() if re.search(r'(?i)error while decoding|invalid (?:data|nal)|corrupt decoded|decode_slice_header error',line)]
    assert not errors,errors
    assert not black,black
    meter=json.loads(re.findall(r'\{\s*"input_i"[\s\S]*?\}',log)[-1])
    assert -19<float(meter['input_i'])<-13,meter
    assert float(meter['input_tp'])<0,meter
    report={'file':FILE.name,'sha256':hashlib.sha256(FILE.read_bytes()).hexdigest(),
            'bytes':FILE.stat().st_size,'dimensions':[1920,1080],
            'fps':FPS,'decodedFrames':decoded,
            'videoDuration':float(video['duration']),'audioDuration':float(audio['duration']),
            'videoCodec':video['codec_name'],'pixelFormat':video['pix_fmt'],
            'colorSpace':video['color_space'],'colorRange':video['color_range'],
            'colorPrimaries':video['color_primaries'],'colorTransfer':video['color_transfer'],
            'audioCodec':audio['codec_name'],'audioSampleRate':int(audio['sample_rate']),
            'integratedLUFS':float(meter['input_i']),'truePeakDBTP':float(meter['input_tp']),
            'loudnessRangeLU':float(meter['input_lra']),
            'decoderErrors':errors,'blackIntervalsOver100ms':black,
            'captionCues':len(captions),'segments':len(EP['segments']),'chapters':len(EP['chapters']),
            'technicalChecksPassed':True}
    dest=ROOT/'output/maya-full/validation.json';dest.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'output/maya-full/ffmpeg-check.log').write_text(log)
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
