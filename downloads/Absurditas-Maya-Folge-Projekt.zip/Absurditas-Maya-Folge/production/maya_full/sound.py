"""Original score and foley synchronized with the finished episode timeline."""
from pathlib import Path
import json,wave
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
EP=json.loads((ROOT/'output/maya-full/episode.json').read_text())
SR=48000
N=EP['durationInFrames']*1600
audio=np.zeros((N,2),dtype=np.float64)
rng=np.random.default_rng(31120261)


def put(at,a,gain=1,pan=0):
    n=round(at*SR)
    if n<0:a=a[-n:];n=0
    a=a[:max(0,N-n)]*gain
    audio[n:n+len(a),0]+=a*np.sqrt((1-pan)/2)
    audio[n:n+len(a),1]+=a*np.sqrt((1+pan)/2)


def noise(duration,width=40):
    n=round(duration*SR)
    src=rng.standard_normal(n+width)
    acc=np.cumsum(src)
    return (acc[width:]-acc[:-width])/width


def brush(at,d=.35,gain=.07,pan=0,width=20):
    t=np.arange(round(d*SR))/SR
    put(at,noise(d,width)*np.sin(np.pi*t/d)**2,gain,pan)


def tap(at,pitch=130,gain=.08,pan=0):
    t=np.arange(round(.18*SR))/SR
    a=np.sin(2*np.pi*pitch*t)*np.exp(-36*t)
    a+=rng.standard_normal(len(t))*.12*np.exp(-t*110)
    put(at,a,gain,pan)


def chime(at,note=74,gain=.03):
    t=np.arange(round(1.8*SR))/SR
    hz=440*2**((note-69)/12)
    a=(np.sin(2*np.pi*hz*t)+.18*np.sin(2*np.pi*hz*2.01*t))*np.exp(-t*3)*np.minimum(t/.015,1)
    put(at,a,gain,np.sin(at)*.35)


def pad(at,duration,notes,gain=.009):
    t=np.arange(round(duration*SR))/SR
    env=np.minimum(t/1.5,1)*np.minimum((duration-t)/1.7,1)
    for j,note in enumerate(notes):
        hz=440*2**((note-69)/12)
        a=(np.sin(2*np.pi*hz*t)+.16*np.sin(2*np.pi*hz*1.002*t))
        a*=env*(.8+.2*np.sin(t*.44+j))
        put(at,a,gain,(-1)**j*.4)


chords=[[50,57,65],[53,60,69],[50,60,65],[50,57,62],[53,60,67],[50,57,65],[48,55,63],[50,57,66]]
for i,c in enumerate(EP['chapters']):
    start=c['startFrame']/30;duration=(c['endFrame']-c['startFrame'])/30
    # Two understated chord sections per chapter keep the score from becoming a loop.
    half=duration/2
    pad(start,half+1,chords[i%len(chords)],.008)
    pad(start+half-1,half+1,chords[i%len(chords)][::-1],.007)
    if i:brush(start-.12,.5,.09,width=45)
    chime(start+.5,74+i%4*2,.022)

duration=N/SR
t=np.arange(N)/SR
envelope=np.minimum(t/1.2,1)*np.minimum((duration-t)/1.2,1)
put(0,noise(duration,310)*envelope*(.55+.35*np.sin(t*.32)),.036)

for seg in EP['segments']:
    start=seg['startFrame']/30;d=seg['durationFrames']/30;scene=seg['scene']
    if scene in ['hook','books','writing','work']:
        for u in np.arange(.5,min(d-.5,6.5),.7):brush(start+u,.2,.045,-.25,12)
    if scene=='build':
        # The hammer rig repeats at 3 radians/second; strike at its low point.
        for u in np.arange(0,d-.1,2*np.pi/3):tap(start+u,95,.075,.45)
        stride=110*1.1/27/2
        for u in np.arange(stride,d-.1,stride):tap(start+u,75,.022,-.4)
    if scene in ['farm','water','dry']:
        # Match the rig's 110-unit stride to its actual world-space travel.
        speed,size,pan={'farm':(13,1.12,-.35),'water':(15,.75,-.35),'dry':(25,.9,.35)}[scene]
        step=110*size/speed/2
        for u in np.arange(step,d-.1,step):tap(start+u,102,.025,pan)
    if scene=='water':
        brush(start+.6,min(4.5,d-1),.11,width=80)
        for u in np.arange(1.3,d-.7,.6):
            tt=np.arange(round(.12*SR))/SR
            a=np.sin(2*np.pi*(410*tt+230*tt*tt))*np.exp(-tt*30)
            put(start+u,a,.026,.15)
    if scene in ['digits','twenty','zero','idea','cycles','longcount']:
        for i,u in enumerate([.5,2.2,4.1,6.4]):
            if u<d-.8:chime(start+u,72+(i%3)*3,.019)
        for cap in seg['captions'][1:]:tap(cap['start'],235,.034,0)
    if scene in ['farm','water','today','legacy']:
        for u in [2.3,6.6]:
            if u<d-1:
                tt=np.arange(round(.18*SR))/SR
                call=np.sin(2*np.pi*(1550*tt+820*tt*tt))*np.sin(np.pi*tt/.18)**3
                put(start+u,call,.006,.7)
    if scene in ['sky','promise','question']:
        brush(start+1.0,.65,.06,.2,55)
    if scene=='end':chime(start+2.7,78,.028)

peak=float(np.max(np.abs(audio)))
assert np.isfinite(peak) and peak<.7
out=ROOT/'public/maya-full-sound.wav'
with wave.open(str(out),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR)
    f.writeframes((audio*32767).astype('<i2').tobytes())
print('Sound:',round(duration,2),'seconds; peak',round(20*np.log10(peak),2),'dBFS')
