const {bundle}=require('@remotion/bundler');
const {selectComposition,renderMedia,openBrowser}=require('@remotion/renderer');
const fs=require('fs');const path=require('path');const cp=require('child_process');
const crypto=require('crypto');

const sourceHash=()=>{
 const hash=crypto.createHash('sha256');
 const visit=(name)=>{
  if(fs.statSync(name).isDirectory())for(const file of fs.readdirSync(name).sort())visit(path.join(name,file));
  else hash.update(name).update(fs.readFileSync(name));
 };
 ['src/MayaEpisode.tsx','src/maya','src/maya-full','production/maya_full/render.cjs'].forEach(visit);
 return hash.digest('hex');
};

(async()=>{
 const ep=JSON.parse(fs.readFileSync('output/maya-full/episode.json','utf8'));
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts')});
 const browserExecutable=process.env.BROWSER_PATH||'/usr/bin/chromium';
 const browser=await openBrowser('chrome',{browserExecutable});
 const folder='output/maya-full/render';fs.mkdirSync(folder,{recursive:true});
 const chosen=process.argv.slice(2).map(Number);const force=process.env.FORCE_RENDER==='1';
 const fingerprint=sourceHash();
 try{
  const composition=await selectComposition({serveUrl,id:'MayaEpisode',puppeteerInstance:browser});
  for(let i=0;i<ep.chapters.length;i++){
   const ch=ep.chapters[i],file=path.resolve(folder,`chapter-${String(i+1).padStart(2,'0')}.mp4`);
   if(chosen.length&&!chosen.includes(i+1))continue;
   let valid=false;
   if(fs.existsSync(file)&&!force){
    try{
     const metadata=JSON.parse(fs.readFileSync(file+'.json','utf8'));
     const x=JSON.parse(cp.execFileSync('ffprobe',['-v','error','-count_frames','-select_streams','v:0','-show_entries','stream=nb_read_frames','-of','json',file],{encoding:'utf8'}));
     valid=metadata.sourceHash===fingerprint&&metadata.startFrame===ch.startFrame&&metadata.endFrame===ch.endFrame&&Number(x.streams[0].nb_read_frames)===ch.endFrame-ch.startFrame;
    }catch{}
   }
   if(valid){console.log(`Retaining chapter ${i+1}: ${ch.title}`);continue;}
   console.log(`START chapter ${i+1}/${ep.chapters.length}: ${ch.title}`,new Date().toISOString());
   let last=-1;
   await renderMedia({serveUrl,composition,puppeteerInstance:browser,outputLocation:file,
    codec:'h264',frameRange:[ch.startFrame,ch.endFrame-1],muted:true,
    videoBitrate:'2200k',encodingMaxRate:'2600k',encodingBufferSize:'5200k',
    x264Preset:'fast',pixelFormat:'yuv420p',concurrency:4,
    onProgress:p=>{const percent=Math.floor(p.progress*10)*10;if(percent!==last){last=percent;console.log(`chapter ${i+1}: ${percent}% (${p.renderedFrames} frames)`);}}});
   fs.writeFileSync(file+'.json',JSON.stringify({startFrame:ch.startFrame,endFrame:ch.endFrame,sourceHash:fingerprint,renderedAt:new Date().toISOString()},null,2));
   console.log(`DONE chapter ${i+1}`,new Date().toISOString());
  }
 }finally{await browser.close({silent:true});}
 const files=ep.chapters.map((c,i)=>path.resolve(folder,`chapter-${String(i+1).padStart(2,'0')}.mp4`));
 if(files.some(f=>!fs.existsSync(f)))throw new Error('Some chapter videos are missing; render them before assembly');
 if(files.some(f=>JSON.parse(fs.readFileSync(f+'.json','utf8')).sourceHash!==fingerprint))throw new Error('Source changed; render remaining chapters before assembly');
 fs.writeFileSync(path.join(folder,'concat.txt'),files.map(f=>`file '${f}'`).join('\n')+'\n');
 cp.execFileSync('ffmpeg',['-v','error','-y','-f','concat','-safe','0','-i',path.join(folder,'concat.txt'),'-c','copy','-video_track_timescale','90000',path.join(folder,'picture.mp4')],{stdio:'inherit'});
 cp.execFileSync('ffmpeg',['-v','error','-y','-i','public/maya-full-voice.wav','-i','public/maya-full-sound.wav',
  '-filter_complex','[0:a][1:a]amix=inputs=2:normalize=0,loudnorm=I=-16:TP=-1.5:LRA=9[a]',
  '-map','[a]','-ar','48000','-ac','2',path.join(folder,'master.wav')],{stdio:'inherit'});
 cp.execFileSync('ffmpeg',['-v','error','-y','-i',path.join(folder,'picture.mp4'),'-i',path.join(folder,'master.wav'),
  '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','128k','-t',String(ep.durationInFrames/30),'-movflags','+faststart',
  '-metadata','title=Die Maya – Eine kleine Form, eine große Geschichte','output/Absurditas-Maya-Folge.mp4'],{stdio:'inherit'});
 console.log('COMPLETE output/Absurditas-Maya-Folge.mp4');
})().catch(e=>{console.error(e);process.exitCode=1;});
