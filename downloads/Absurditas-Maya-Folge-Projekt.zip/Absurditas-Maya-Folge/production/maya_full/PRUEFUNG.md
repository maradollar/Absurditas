# Prüfbericht der gelieferten Maya-Folge

Stand: 3. November 2026. Dieser Bericht bezieht sich auf die tatsächlich
exportierte Datei `Absurditas-Maya-Folge.mp4`; ihre SHA-256-Prüfsumme steht im maschinenlesbaren
Bericht `output/maya-full/validation.json`.

## Technische Prüfung bestanden

- 1920 × 1080 Pixel, H.264, YUV 4:2:0, begrenztes BT.709
  mit vollständig gesetzten Farbmetadaten.
- 7864 tatsächlich dekodierte Bilder, konstante 30 Bilder pro Sekunde.
- Bilddauer 262.133333 Sekunden, Tondauer 262.133000 Sekunden.
- AAC-Stereoton mit 48000 Hz; -15.99 LUFS integriert,
  -3.96 dBTP, Dynamikbereich 2.90 LU.
- Vollständiges Dekodieren mit FFmpeg ohne erkannte Dekodierfehler.
- Keine erkannten Schwarzsequenzen ab 100 Millisekunden bei mindestens 98 Prozent
  schwarzen Bildpunkten und einer Schwarzschwelle von zwei Prozent.
- 65 Untertitelsätze, 25 Szenen und 8 Kapitel;
  Satztexte und Zeiten stimmen mit der erzeugten Sprach-Zeitleiste überein.
- Die Farbkorrektur konvertiert die Bildwerte aus dem JPEG-Farbbereich in BT.709;
  anschließend werden die H.264-Farbmetadaten vollständig gesetzt.

## Bild- und Projektkontrolle

Alle 25 Szenen wurden zunächst als Kontrollbilder betrachtet. Anschließend wurden
25 Bilder aus dem zusammengesetzten Film sowie zusätzliche Bilder der Zahlenfolge,
der ersten Kapitel, der Wissensszenen und der finalen Farbkonvertierung gesichtet.
Bewegungszustände wurden unter anderem am Pyramidenbau verglichen. Verdeckte
Beschriftungen und zu tief platzierte Kinder in der Unterrichtsszene wurden korrigiert.

Die Projektquellen wurden in einem separaten Ordner mit einem frischen `npm ci`
installiert und erfolgreich mit TypeScript geprüft. Drei dort gerenderte Bilder
(Schreibstube, Schrift, Unterricht) stimmen pixelgenau mit den entsprechenden
Produktions-Kontrollbildern überein. Der abschließende Farbexport und der vollständige
Validator wurden auf der fertigen Produktionsdatei ausgeführt.

Alle Sprechersegmente enthalten Audio und haben die erwartete Länge; beide
Eingangsspuren sind endlich und ohne digitale Übersteuerung. Sechs Abschnitte
wurden zusätzlich mit lokalem Whisper rücktranskribiert. Die Rücktranskription ist
eine Plausibilitätsprobe mit eigenen Erkennungsfehlern, insbesondere bei Eigennamen;
sie ist keine verlässliche Aussprachebewertung.

Eine vollständige audiovisuelle Echtzeitsichtung durch einen menschlichen Cutter
oder eine facharchäologische Prüfung jedes Bilddetails wurde nicht vorgenommen.
Die Architektur, Zeichenillustrationen, Landkarten-Verbindungen und Figuren sind
schematisch; ihre Konventionen stehen in `QUELLEN.md`.
