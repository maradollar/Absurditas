"""Check the exported file itself. Does not claim human audiovisual review."""
import json
import argparse
import re
import subprocess
from fractions import Fraction
from pathlib import Path

root = Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('file', nargs='?', type=Path, default=root/'output'/'absurditas-preview.mp4')
args=parser.parse_args()
video = args.file.resolve(strict=True)


def run(args):
    return subprocess.run(args, check=True, text=True, capture_output=True)


probe = json.loads(run(['ffprobe', '-v', 'error', '-count_frames',
                       '-show_streams', '-show_format', '-of', 'json', str(video)]).stdout)
vs = next(s for s in probe['streams'] if s['codec_type'] == 'video')
au = next(s for s in probe['streams'] if s['codec_type'] == 'audio')
assert (vs['width'], vs['height'], vs['r_frame_rate']) == (1920, 1080, '30/1')
assert Fraction(vs['avg_frame_rate']) == 30, 'Expected constant 30 fps'
assert int(vs['nb_read_frames']) == 900
assert abs(float(vs['duration']) - 30) < .01
assert abs(float(au['duration']) - 30) < .1
decode = run(['ffmpeg', '-v', 'error', '-i', str(video), '-f', 'null', '-'])
assert not decode.stderr.strip(), decode.stderr
black = run(['ffmpeg', '-hide_banner', '-i', str(video), '-vf',
             'blackdetect=d=0.1:pix_th=0.1', '-an', '-f', 'null', '-']).stderr
assert 'black_start:' not in black, 'Unexpected black frames'
volume = run(['ffmpeg', '-hide_banner', '-i', str(video), '-af',
              'loudnorm=I=-16:TP=-1.5:LRA=9:print_format=json',
              '-vn', '-f', 'null', '-']).stderr
match = re.search(r'\{\s*"input_i".*?\}', volume, re.S)
assert match, 'No current loudness measurement'
levels = json.loads(match.group())
assert float(levels['input_tp']) < 0, 'True-peak clipping'
report = {'file': video.name, 'size_bytes': video.stat().st_size,
          'resolution': [1920, 1080], 'frames': 900, 'fps': 30,
          'video_duration_seconds': float(vs['duration']),
          'audio_duration_seconds': float(au['duration']),
          'integrated_loudness_lufs': float(levels['input_i']),
          'true_peak_dbtp': float(levels['input_tp']),
          'decode_errors': False, 'black_sections_over_100ms': False,
          'visual_review': 'contact sheet and selected stills; not full real-time playback',
          'historical_fact_check': 'pending', 'status': 'passed'}
video.with_suffix('.validation.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
