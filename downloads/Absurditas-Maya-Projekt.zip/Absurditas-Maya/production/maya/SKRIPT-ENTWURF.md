# Die Maya und die Null · 30-Sekunden-Entwurf

## Status

Der erste Referenzupload `videoplayback.mp4` überschritt die Transfergrenze von
32 MiB. Der anschließend hochgeladene Film „Wir wissen endlich mehr über die
wichtigste Zivilisation.mp4“ ist mit 28.438.944 Bytes lesbar und wurde lokal
ausgewertet: 1.018,17 Sekunden, 426 × 240, 30 fps, AAC-Stereoton. Die geringe
Auflösung erlaubt eine Untersuchung von Farbaufbau, Komposition und groben
Bewegungsphasen; feine Linien und kleine Texte sind nur eingeschränkt lesbar.

Es wurden Kontaktbögen des Einstiegs, der gesamten Laufzeit und des Endes
erstellt und gesichtet. Das ist keine vollständige audiovisuelle Echtzeitsichtung.

Sichtbare Merkmale: Dunkelviolett und Petrol neben warmem Fackellicht; klar
getrennte Farbebenen statt gleichmäßig schwerer schwarzer Konturen; kräftige
Hell-Dunkel-Hierarchie; naher Vordergrund zur Tiefenstaffelung; runde Masken
verbinden arbeitende Figuren mit Erklärdarstellungen. Im weiteren Film wechseln
lichtvolle Stadt- und Landschaftsdioramen mit dunklen Wissensdarstellungen.
Absurditas soll diese Gestaltungsmittel für eigene Maya-Szenen nutzen, nicht
Figuren, Szenen oder Grafiken aus dem Referenzvideo übernehmen.

Stimme A wurde ausgewählt. Die Stilprobe ist als 30-Sekunden-Film mit
1920 × 1080 und 30 fps umgesetzt. Zwischen den Sätzen wurden Bildpausen ergänzt,
ohne Sprechtempo oder Tonhöhe zu verändern. Die tatsächlichen Satzzeiten stehen
in `output/maya/film-timing.json`. Eine exakte Kopie der Referenz wird nicht behauptet.

## Sprechertext

Dieses Zeichen sieht aus wie eine Muschel.
Für die Maya bedeutete es: null.
Ein Punkt stand für eins, ein Balken für fünf.
Aber der eigentliche Trick war die Anordnung: Zahlen über Zahlen, wie Stockwerke.
So konnten sie auch riesige Zeiträume festhalten.
Sie bauten große Städte, entwickelten eine Schrift und beobachteten die Sterne.
Und diese Geschichte ist nicht einfach verschwunden.
Maya leben bis heute.

## Zusammenhängende Bildhandlung

Keine Reihe von Textfolien. Das zentrale Zeichen trägt die Kamerabewegung und
führt von Zahlendarstellung zu Zeitrechnung, Stadt und Gegenwart. Die folgende
Tabelle ist die ursprüngliche Planung. Die endgültige Umsetzung und ihre Zeiten
sind in `README.md` dokumentiert.

| Zielzeit | Bildhandlung | Bewegung und Übergang |
|---|---|---|
| 0–5 s | Nahaufnahme eines muschelförmigen Nullzeichens; eine Hand vollendet seine Form. | Kamera nähert sich, die Zeichnung wird zur eigenständigen Form. Kurze Pause auf „null“. |
| 5–10 s | Ein Punkt und ein Balken erscheinen als Teile eines lebendigen Zahlenspiels. | Fünf Punkte sammeln sich, ihre Bewegung endet in einem Balken. Ein einziges räumliches Spielfeld statt Tafelschnitt. |
| 10–16 s | Zahlengruppen ordnen sich auf mehreren Ebenen. Ein Nullzeichen hält eine unbesetzte Stelle frei. | Die Kamera folgt der Anordnung nach oben. Die vertikalen Stellen werden über Bewegung lesbar. |
| 16–22 s | Die geometrischen Ebenen öffnen sich zu einer Stadtansicht; eine schreibende und eine beobachtende Figur arbeiten. | Architektur wächst aus einer visuellen Überleitung, ohne zu behaupten, die Pyramidenform sei aus dem Zahlensystem abgeleitet. |
| 22–27 s | Ein gezeichnetes Himmelsmotiv und ein beschriebenes Blatt verbinden Wissensgebiete. | Formanschluss zwischen kreisförmigem Himmelsobjekt, Zeichen und Auge einer Figur. |
| 27–30 s | Übergang zu heutigen Menschen; das kleine Zahlzeichen bleibt als Verbindung erhalten. | Kleidung und Umgebung verändern sich, der Bildfluss bleibt bestehen. Abschluss mit „Maya leben bis heute“. |

## Sachliche Leitplanken

- Die Null nicht als ausschließlich von den Maya erfundene Idee darstellen;
  verschiedene Kulturen entwickelten entsprechende mathematische Konzepte.
- Muschelförmiges Nullzeichen, Punkte und Balken sind ein ausgewähltes
  Darstellungsbeispiel; es existieren auch andere Zeichenformen.
- Die allgemeine Stellenwertdarstellung und kalendarische Sonderregeln nicht
  unbemerkt vermischen. Bei konkreten Zahlen für den Kalender die modifizierte
  Stellenfolge gesondert prüfen.
- Es gab mehrere Maya-Staaten und Städte. Keine einheitliche Kaiserreich-
  Erzählung erfinden.
- Maya sind keine verschwundene Bevölkerung. Die Darstellung der Gegenwart
  gehört zur Geschichte.
- Vor einer öffentlichen Veröffentlichung Zahlenzeichen, Kleidung,
  Architektur und Einzelaussagen anhand verlässlicher Fachquellen prüfen.

Der mathematische Kern wurde mit dem Abschnitt „Early Numeration Systems“ des
OpenStax-Lehrbuchs *Contemporary Mathematics* abgeglichen: Punkt = 1, Balken = 5,
vertikale Stellenwertanordnung und eigenes Nullzeichen. Quelle:
[OpenStax-Originalmodul](https://github.com/openstax/osbooks-contemporary-mathematics/blob/main/modules/m00053/index.cnxml).
Es werden keine Lehrbuchabbildungen übernommen. Konkrete Kleidung, Architektur
und Himmelsdarstellungen sind damit noch nicht überprüft.

## Stimme

Kostenlose lokale Teststimme: Piper/Thorsten über sherpa-onnx. Das offizielle
Modellpaket enthält eine Modellkarte mit CC0-Datensatzangabe und verweist auf
[Thorsten-Voice](https://github.com/thorstenMueller/Thorsten-Voice).
Es handelt sich um eine vorhandene, öffentlich bereitgestellte synthetische
Stimme. Die Referenzstimme wurde weder kopiert noch als Trainingsmaterial genutzt.

```bash
cd /workspace/Absurditas
PYTHONPATH=/workspace/.sherpa-tools python3 production/maya/tts.py
```

Die kurze Probe enthält nur Sprache, damit Klang und Artikulation beurteilt
werden können. Musik und Effekte werden erst bei der finalen Mischung ergänzt.
Technische Prüfung und automatische Rücktranskription können Auslassungen
finden, beweisen aber weder natürlichen Klang noch eine menschliche Herkunft.

Der Referenzclip enthält eine Tonspur. Ihre Herkunft wurde nicht durch
Produktionsangaben oder Sprechercredits belegt. Eine vermeintlich sichere
KI-Erkennung allein aus Klang, Spektrogramm oder Tonqualität wäre nicht belastbar.
