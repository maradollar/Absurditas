const {bundle}=require('@remotion/bundler');
const {selectComposition,renderStill}=require('@remotion/renderer');
const path=require('path');
const fs=require('fs');
(async()=>{
 const serveUrl=await bundle({entryPoint:path.resolve('src/index.ts')});
 const browserExecutable='/usr/bin/chromium';
 const composition=await selectComposition({serveUrl,id:'Maya',browserExecutable});
 const args=process.argv.slice(2).map(Number);
 const frames=args.length?args:[18,51,108,168,219,324,402,459,534,618,684,765,864];
 fs.mkdirSync('output/maya/stills',{recursive:true});
 for(const frame of frames){
  await renderStill({serveUrl,composition,browserExecutable,frame,output:`output/maya/stills/frame-${String(frame).padStart(3,'0')}.png`});
  console.log('Rendered frame',frame);
 }
})().catch(e=>{console.error(e);process.exitCode=1;});
