"""Keep selected voice A; add deliberate picture pauses without changing pitch/speed."""
import json
from pathlib import Path
import subprocess
import numpy as np
import soundfile as sf

root=Path(__file__).resolve().parents[2]
source=root/'output/maya/Maya-Stimme-Entwurf.wav'
marks=json.loads((root/'output/maya/voice-timing.json').read_text())
samples,sr=sf.read(source,dtype='float32')
pauses=[.48,.68,.48,.78,.52,.72,.34,0]
parts=[np.zeros(round(.18*sr),dtype=np.float32)]
elapsed=.18
timeline=[]
for i,mark in enumerate(marks):
    piece=samples[round(mark['start']*sr):round(mark['end']*sr)]
    duration=len(piece)/sr
    timeline.append({**mark,'start':elapsed,'end':elapsed+duration})
    parts.append(piece);elapsed+=duration
    gap=np.zeros(round(pauses[i]*sr),dtype=np.float32)
    parts.append(gap);elapsed+=len(gap)/sr
audio=np.concatenate(parts)
assert len(audio)<30*sr
audio=np.pad(audio,(0,30*sr-len(audio)))
out=root/'output/maya/maya-voice-paced.wav';sf.write(out,audio,sr)
subprocess.run(['ffmpeg','-v','error','-y','-i',str(out),'-af',
                'loudnorm=I=-17:TP=-2:LRA=8','-ar','48000','-ac','2',
                str(root/'public/maya-voice.wav')],check=True)
(root/'output/maya/film-timing.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2))
(root/'src/maya/timing.ts').write_text('export const narration = '+json.dumps(timeline,ensure_ascii=False,indent=2)+' as const;\n')
print('Selected voice A, unchanged speaking speed; final speech ends',round(elapsed,3),'seconds')
for q in timeline:print(round(q['start'],2),round(q['end'],2),q['text'])
