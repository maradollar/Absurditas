"""Local German voice audition, not a clone of the uploaded reference.

Requires sherpa-onnx, soundfile and the officially distributed Piper/Thorsten
model. No remote speech service and no API key.
"""
import argparse
import json
from pathlib import Path
import subprocess

import numpy as np
import sherpa_onnx
import soundfile as sf


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--model-dir',type=Path,
                        default=Path('/workspace/.models/vits-piper-de_DE-thorsten-high'))
    parser.add_argument('--speed',type=float,default=.84)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[2]
    out=root/'output'/'maya'
    out.mkdir(exist_ok=True,parents=True)
    model=args.model_dir.resolve(strict=True)
    cfg=sherpa_onnx.OfflineTtsConfig(
        model=sherpa_onnx.OfflineTtsModelConfig(
            vits=sherpa_onnx.OfflineTtsVitsModelConfig(
                model=str(model/'de_DE-thorsten-high.onnx'),
                tokens=str(model/'tokens.txt'),
                data_dir=str(model/'espeak-ng-data')),
            num_threads=4),
        max_num_sentences=1)
    if not cfg.validate():
        raise RuntimeError('TTS configuration invalid')
    tts=sherpa_onnx.OfflineTts(cfg)
    lines=(root/'production'/'maya'/'narration.txt').read_text().splitlines()
    pieces=[]
    marks=[]
    elapsed=0
    sample_rate=0
    for i,text in enumerate(lines):
        if not text.strip():
            continue
        audio=tts.generate(text,sid=0,speed=args.speed)
        samples=np.asarray(audio.samples,dtype=np.float32)
        sample_rate=audio.sample_rate
        seconds=len(samples)/sample_rate
        marks.append({'sentence':i+1,'start':elapsed,'end':elapsed+seconds,'text':text})
        pieces.append(samples)
        elapsed+=seconds
        # Narration pacing; the zero reveal gets a little more breathing room.
        if i<len(lines)-1:
            gap=.4 if i==1 else .2
            pause=np.zeros(round(gap*sample_rate),dtype=np.float32)
            pieces.append(pause);elapsed+=len(pause)/sample_rate
        print(f'{i+1}: {seconds:.2f}s {text}',flush=True)
    full=np.concatenate(pieces)
    sf.write(out/'Maya-Stimme-Entwurf.wav',full,sample_rate)
    # First three sentences are enough to judge basic articulation and timbre.
    sample_end=round(marks[min(2,len(marks)-1)]['end']*sample_rate)
    sf.write(out/'Maya-Stimmprobe.wav',full[:sample_end],sample_rate)
    (out/'voice-timing.json').write_text(json.dumps(marks,ensure_ascii=False,indent=2))
    for name in ['Maya-Stimmprobe','Maya-Stimme-Entwurf']:
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(out/(name+'.wav')),
                        '-af','loudnorm=I=-17:TP=-2:LRA=8','-ar','44100',
                        '-c:a','libmp3lame','-b:a','160k',str(out/(name+'.mp3'))],check=True)
    for source,target in [('Maya-Stimmprobe','Maya-Stimmprobe-ruhiger'),
                          ('Maya-Stimme-Entwurf','Maya-Stimme-ruhiger')]:
        subprocess.run(['ffmpeg','-v','error','-y','-i',str(out/(source+'.wav')),
                        '-af','atempo=0.88,loudnorm=I=-17:TP=-2:LRA=8',
                        '-ar','44100','-c:a','libmp3lame','-b:a','160k',
                        str(out/(target+'.mp3'))],check=True)
    print(f'Full draft: {len(full)/sample_rate:.2f}s; audition: {sample_end/sample_rate:.2f}s')


if __name__=='__main__':
    main()
