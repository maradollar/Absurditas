"""Original soundscape for the Maya film; no stock audio or music services."""
from pathlib import Path
import wave
import numpy as np

SR=48000
mix=np.zeros((30*SR,2),dtype=np.float64)
rng=np.random.default_rng(3112026)


def add(at,a,gain=1.,pan=0.):
    i=round(at*SR)
    if i<0:a=a[-i:];i=0
    a=a[:max(0,len(mix)-i)]*gain
    mix[i:i+len(a),0]+=a*np.sqrt((1-pan)/2)
    mix[i:i+len(a),1]+=a*np.sqrt((1+pan)/2)


def noise(seconds,width=25):
    a=rng.standard_normal(round(seconds*SR))
    return np.convolve(a,np.ones(width)/width,'same')


def brush(at,seconds=.4,gain=.06,pan=0,width=15):
    t=np.arange(round(seconds*SR))/SR
    a=noise(seconds,width)*np.sin(np.pi*t/seconds)**2
    add(at,a,gain,pan)


def knock(at,freq=140,gain=.07,pan=0):
    t=np.arange(round(.2*SR))/SR
    a=np.sin(2*np.pi*freq*t)*np.exp(-t*35)
    a+=rng.standard_normal(len(t))*.07*np.exp(-t*90)
    add(at,a,gain,pan)


def bell(at,note=74,gain=.04,seconds=1.5,pan=0):
    t=np.arange(round(seconds*SR))/SR
    hz=440*2**((note-69)/12)
    a=(np.sin(2*np.pi*hz*t)+.22*np.sin(2*np.pi*hz*2.01*t))
    a*=np.exp(-t*4)*np.minimum(t/.012,1)
    add(at,a,gain,pan)


def pad(at,notes,seconds,gain=.006):
    t=np.arange(round(seconds*SR))/SR
    env=np.minimum(t/1.6,1)*np.minimum((seconds-t)/1.8,1)
    for j,n in enumerate(notes):
        hz=440*2**((n-69)/12)
        a=(np.sin(2*np.pi*hz*t)+.25*np.sin(2*np.pi*(hz*1.001)*t))
        a*=env*(.85+.15*np.sin(t*.7+j))
        add(at,a,gain,(-1)**j*.35)


# Soft original tonal bed, not a reconstruction of historical Maya music.
pad(0,[50,57,65],8,.0045)
pad(6.5,[50,60,65],9,.004)
pad(13,[53,60,69],10,.004)
pad(21,[50,57,65,72],9,.004)
for at,note in [(2.78,74),(5.33,77),(7.15,72),(9.65,74),(13.8,81),(17.12,77),(21.6,79),(25.03,81),(28.15,74)]:
    bell(at,note,.025,1.7,pan=float(np.sin(at)*.4))

# Air and small, non-specific forest calls.
t=np.arange(30*SR)/SR
env=np.minimum(t/.6,1)*np.minimum((30-t)/.7,1)
add(0,noise(30,260)*env*(.5+.5*np.sin(t*.6)),.045)
for at in [1.4,16.5,17.7,24.2,27.5]:
    q=np.arange(round(.24*SR))/SR
    call=np.sin(2*np.pi*(1450*q+950*q*q))*np.sin(np.pi*q/.24)**3
    add(at,call,.005,pan=.7)

for at in [.28,.66,1.1,1.55,2.05]:brush(at,.24,.055,-.28,10)
brush(2.7,1.2,.08,.25,55)
brush(4.58,.58,.09,.1,22)
knock(5.32,300,.06,-.12)
for i,at in enumerate([6.08,6.2,6.32,6.44,6.56]):knock(at,360+i*27,.033,(i-2)*.18)
brush(6.8,.5,.055,0,20)
for at in [8.6,9.45,10.4]:knock(at,130,.065,.1)
brush(13.24,.72,.08,.2,45)
for at in np.arange(17.25,19,.36):knock(at,98,.022,-.45)
for at in [18.7,19.1,19.5,20.0]:brush(at,.17,.024,-.15,12)
brush(21.9,1.48,.09,0,26)
for at in np.arange(25.2,28.8,.4):knock(at,105,.018,.5)

out=Path(__file__).resolve().parents[2]/'public'/'maya-sound.wav'
peak=float(np.max(np.abs(mix)))
assert peak<.5
with wave.open(str(out),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(SR)
    f.writeframes((mix*32767).astype('<i2').tobytes())
print(out,'peak',round(20*np.log10(peak),2),'dBFS')
