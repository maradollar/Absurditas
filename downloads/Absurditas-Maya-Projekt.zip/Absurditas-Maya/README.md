# Absurditas · Die Maya und die Null

30-Sekunden-Motion-Design-Stilprobe, Stimme A, 1920 × 1080, 30 fps.
Eigene SVG-Illustrationen und Figuren, prozedurale Formübergänge, Kamerafahrten,
Lichtwechsel und selbst erzeugte Musik/Geräusche. Die hochgeladene Referenz wurde
als Gestaltungsreferenz ausgewertet; keine ihrer Bilder oder Tonaufnahmen ist im
fertigen Film enthalten.

## Rendern im vorhandenen Projekt

```bash
cd Absurditas-Maya
npm ci
npm run typecheck
npm run render:maya
python3 production/validate.py output/Absurditas-Maya.mp4
```

Chromium ist auf dieser Cloud-Maschine unter `/usr/bin/chromium` vorhanden.
Es benötigt hier die freigegebene Prozessausführung. Auf anderen Systemen den
Browserpfad anpassen. Der bestehende Checkout reicht aus; kein weiteres
Git-Worktree erforderlich.

## Bild- und Tonablauf

| Filmzeit | Umsetzung |
|---|---|
| 0–5,25 s | Kameranäherung an eine beleuchtete Schreibstube, Schreibgeste, schwebendes muschelförmiges Nullzeichen, Übergang über dessen Kreisform. |
| 4,45–14,05 s | Ein Punkt wird zu fünf Punkten und einem Balken. Die Zeichen ordnen sich mit einer Figur auf einer räumlichen Stele an. Die Kreisform bereitet den Übergang zur Sonne vor. |
| 13,15–22 s | Ein heller Tageszyklus, eine Stadtansicht und eine seitliche Kamerafahrt zur schreibenden und zur sternbeobachtenden Figur. Die Lichtfarben gehen kontinuierlich ineinander über. |
| 21,8–23,4 s | Bewegte Blattkante verbindet Vergangenheit und Gegenwart. |
| 23,4–30 s | Heutige Figuren mit Tablet, Korb und einer winkenden Geste; langsamere Kamerafahrt und dezente Absurditas-Marke im weiterlaufenden Bild. |

Die Intervalle überlappen durch die animierten Übergänge. Der genaue Satzbeginn
steht in `output/maya/film-timing.json`; die Stimme endet bei 26,46 s. Es wurde
nur zwischen den Sätzen zusätzliche Stille ergänzt. Die gewählte Stimme A wurde
nicht geklont, in der Tonhöhe verändert oder langsamer abgespielt.

## Quelldateien

- `src/MayaFilm.tsx`: Komposition und Übergänge.
- `src/maya/art.tsx`: Farbwelt, Formen, Nullzeichen, Architektur, Licht und Natur.
- `src/maya/Person.tsx`: Figurenrig mit Gelenken und an den Weg gekoppelten Schritten.
- `src/maya/TempleAndNumbers.tsx`: Schreibstube, Zahlmorphing und Stele.
- `src/maya/CityAndPresent.tsx`: Stadt, Lichtzyklus und Gegenwart.
- `production/maya/narration.txt`: Sprechertext.
- `production/maya/prepare_audio.py`: Satzpausen der gewählten Stimme.
- `production/maya/sound.py`: originale synthetische Geräusche und Musik.
- `production/maya/tts.py`: optionale lokale Sprachsynthese über sherpa-onnx.

Die fertigen Audioeingänge sind `public/maya-voice.wav` und `public/maya-sound.wav`.
Ein anderer Text oder eine andere Stimme erfordert eine erneute Abstimmung der
Szenenzeitpunkte. Dieses Projekt bildet die konkrete Stilprobe ab.

## Herkunft und Prüfstand

Die Stimme ist synthetisch: Piper/Thorsten über sherpa-onnx. Die offizielle
Modellkarte verweist auf den CC0-Datensatz
[Thorsten-Voice](https://github.com/thorstenMueller/Thorsten-Voice).
Schrift: DejaVu; Lizenz unter `public/FONT-LICENSE.txt`. Remotion und die übrigen
Abhängigkeiten haben eigene Lizenzbedingungen.

Der mathematische Kern wurde mit OpenStax, *Contemporary Mathematics*, Abschnitt
[Early Numeration Systems](https://github.com/openstax/osbooks-contemporary-mathematics/blob/main/modules/m00053/index.cnxml)
abgeglichen. Es wurden keine Abbildungen aus dem Lehrbuch übernommen. Figuren,
Kleidung, Architektur und Peilgestell sind stilisierte Veranschaulichungen,
keine Rekonstruktionen eines bestimmten Fundorts oder bestimmter Personen.

Technische Prüfung des tatsächlichen Exports bestanden: 900 Bilder, konstante
30 fps, 30,00 s Bilddauer, 30,016 s AAC-Ton einschließlich Codec-Auffüllung,
keine Dekodierfehler und keine erkannten Schwarzsequenzen über 100 ms.
Gemessen: −17,45 LUFS integriert, −4,55 dBTP. Kontrollbilder, der Kontaktbogen
des fertigen Videos und ein Bewegungs-Kontaktbogen wurden gesichtet.
Eine vollständige audiovisuelle Echtzeitsichtung und die Prüfung sämtlicher
historischer Bilddetails stehen aus.

Das Archiv enthält die verwendeten Audioeingänge bereits. Für den Videoexport genügen Node.js, npm und Chromium. Die Python-Schritte sind nur zum Ändern der Audiospuren erforderlich.
