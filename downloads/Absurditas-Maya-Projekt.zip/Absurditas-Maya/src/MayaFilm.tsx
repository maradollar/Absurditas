import React from 'react';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame} from 'remotion';
import {P,MayaDefs,span,s,lerp,Zero} from './maya/art';
import {Temple,Numbers} from './maya/TempleAndNumbers';
import {City,Present} from './maya/CityAndPresent';

export const MayaFilm:React.FC=()=>{
 const frame=useCurrentFrame(),t=frame/30;
 const first=span(t,4.45,5.25),second=span(t,13.15,14.05),page=span(t,21.8,23.4);
 const intro=t<5.25,math=t>=4.45&&t<14.05,city=t>=13.15&&t<23.4,present=t>=21.8;
 return <AbsoluteFill style={{background:P.night}}>
  <style>{`@font-face{font-family:Display;src:url('${staticFile('display.ttf')}')}@font-face{font-family:Body;src:url('${staticFile('body.ttf')}')}`}</style>
  <Audio src={staticFile('maya-voice.wav')}/><Audio src={staticFile('maya-sound.wav')}/>
  <svg width="1920" height="1080" viewBox="0 0 1920 1080">
   <MayaDefs/>
   <defs><clipPath id="m-iris-one"><circle cx="1160" cy="510" r={first*2310}/></clipPath>
    <clipPath id="m-iris-two"><circle cx="1450" cy="300" r={second*2500}/></clipPath>
    <clipPath id="m-page"><path d={`M${1920-page*2500} -500Q${2250-page*3000} 400 ${2020-page*3100} 1500H4000V-500Z`}/></clipPath>
   </defs>
   {intro&&<Temple t={t}/>}
   {math&&<g clipPath={t<5.25?'url(#m-iris-one)':undefined}><Numbers t={t}/></g>}
   {t>4.45&&t<5.17&&<circle cx="1160" cy="510" r={first*2310+3} fill="none" stroke={P.gold} strokeWidth="5" opacity={.6*(1-first)}/>}
   {city&&<g clipPath={t<14.05?'url(#m-iris-two)':undefined}><City t={t}/></g>}
   {present&&<g clipPath={t<23.4?'url(#m-page)':undefined}><Present t={t}/></g>}
   {page>0&&page<1&&<path d={`M${1940-page*2500} -500Q${2180-page*3000} 400 ${1970-page*3100} 1500L${2030-page*3100} 1500Q${2320-page*3000} 400 ${2000-page*2500}-500Z`} fill={P.cream} opacity=".95"/>}
   {/* No opening title card; the imagery starts on frame zero. */}
   <rect width="1920" height="1080" fill={P.deep} opacity={.1*(1-span(t,0,.6))}/>
  </svg>
 </AbsoluteFill>;
};
