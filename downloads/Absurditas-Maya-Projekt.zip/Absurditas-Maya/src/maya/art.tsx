import React from 'react';
import {makeStar} from '@remotion/shapes';
import {interpolateColors} from 'remotion';

export const P={night:'#101633',deep:'#081F37',plum:'#33164D',violet:'#6C3979',teal:'#147C83',jade:'#34D6BB',mint:'#A8F0D4',gold:'#FFC568',light:'#FFF0B4',coral:'#F47765',red:'#C64D69',stone:'#4B9F9F',skin:'#CE7954',hair:'#252042',cream:'#FFE6B9'};
export const sat=(n:number)=>Math.max(0,Math.min(1,n));
export const s=(n:number)=>{const p=sat(n);return p*p*(3-2*p);};
export const e=(n:number)=>1-Math.pow(1-sat(n),3);
export const lerp=(a:number,b:number,p:number)=>a+(b-a)*p;
export const tint=(a:string,b:string,p:number)=>interpolateColors(sat(p),[0,1],[a,b]);
export const span=(t:number,a:number,b:number)=>s((t-a)/(b-a));
export const hash=(n:number)=>{const x=Math.sin(n*127.17+43.7)*43758.5453;return x-Math.floor(x);};
export const project=(x:number,y:number,z:number,fx:number,fy:number)=>({x:(x-fx)*z+960,y:(y-fy)*z+540});
export const camera=(z:number,fx=960,fy=540)=>`translate(960 540) scale(${z}) translate(${-fx} ${-fy})`;

export const MayaDefs:React.FC=()=> <defs>
 <linearGradient id="m-sky" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#1B153D"/><stop offset=".55" stopColor="#153A53"/><stop offset="1" stopColor="#1C777A"/></linearGradient>
 <linearGradient id="m-dawn" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#27335D"/><stop offset=".48" stopColor="#CB777D"/><stop offset="1" stopColor="#FFD891"/></linearGradient>
 <linearGradient id="m-cave" x1="0" y1="0" x2="1" y2=".8"><stop stopColor="#10172F"/><stop offset=".65" stopColor="#361A4E"/><stop offset="1" stopColor="#563052"/></linearGradient>
 <linearGradient id="m-floor" x1="0" y1="0" x2=".6" y2="1"><stop stopColor="#794764"/><stop offset=".5" stopColor="#48284E"/><stop offset="1" stopColor="#171E3B"/></linearGradient>
 <linearGradient id="m-stone" x1="0" y1="0" x2="1" y2=".3"><stop stopColor="#69C3B7"/><stop offset=".7" stopColor="#30959D"/><stop offset="1" stopColor="#276E83"/></linearGradient>
 <linearGradient id="m-gold" x1="0" y1="0" x2=".3" y2="1"><stop stopColor="#FFF1AC"/><stop offset=".45" stopColor="#FFC26C"/><stop offset="1" stopColor="#E68763"/></linearGradient>
 <linearGradient id="m-skin" x1="0" y1="0" x2="1" y2=".2"><stop stopColor="#EAAB75"/><stop offset=".7" stopColor="#CC7B58"/><stop offset="1" stopColor="#AD5860"/></linearGradient>
 <linearGradient id="m-tunic" x1="0" y1="0" x2=".9" y2=".7"><stop stopColor="#FFE8BD"/><stop offset="1" stopColor="#C99686"/></linearGradient>
 <radialGradient id="m-aura"><stop stopColor="#FFC568" stopOpacity=".28"/><stop offset=".45" stopColor="#F3A967" stopOpacity=".10"/><stop offset="1" stopColor="#F3A967" stopOpacity="0"/></radialGradient>
 <radialGradient id="m-jade-aura"><stop stopColor="#6AEFD8" stopOpacity=".45"/><stop offset=".4" stopColor="#34D6BB" stopOpacity=".12"/><stop offset="1" stopColor="#34D6BB" stopOpacity="0"/></radialGradient>
 <radialGradient id="m-lamp"><stop stopColor="#FFE9AC" stopOpacity=".5"/><stop offset=".4" stopColor="#F9905F" stopOpacity=".14"/><stop offset="1" stopColor="#F47765" stopOpacity="0"/></radialGradient>
 <linearGradient id="m-leaf" x1="0" y1="0" x2="1" y2="1"><stop stopColor="#197682"/><stop offset="1" stopColor="#093349"/></linearGradient>
 <linearGradient id="m-water" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#3CBFAF"/><stop offset="1" stopColor="#1D677C"/></linearGradient>
 <filter id="m-soft"><feGaussianBlur stdDeviation="7"/></filter>
</defs>;

export const Zero:React.FC<{x?:number;y?:number;size?:number;t?:number;opacity?:number;glow?:boolean;gold?:boolean}>=({x=0,y=0,size=1,t=0,opacity=1,glow=true,gold=true})=><g transform={`translate(${x} ${y}) scale(${size})`} opacity={opacity}>
 {glow&&<ellipse rx="235" ry="190" fill={gold?'url(#m-aura)':'url(#m-jade-aura)'}/>}
 <path d="M-112 13C-110-29-71-64 0-66C71-64 110-29 112 13C108 55 61 78 0 77C-61 78-108 55-112 13Z" fill={gold?'url(#m-gold)':P.jade}/>
 <path d="M-104 13Q0-6 104 13Q88 58 0 65Q-88 58-104 13Z" fill={gold?'#D47A65':'#1D9299'}/>
 <path d="M-93 2C-72-32-40-48 0-49C40-48 72-32 93 2C47-10-47-10-93 2Z" fill={P.plum}/>
 <path d="M-62-19Q-42-49-25-46L-31-8L-55-5ZM-12-47Q0-54 12-47L19-8H-19ZM25-46Q42-49 62-19L55-5L31-8Z" fill={gold?P.light:P.mint}/>
 <path d="M-88 26Q0 12 88 26M-66 44Q0 34 66 44" stroke={gold?'#FFDB87':'#67DCCC'} strokeWidth="7" fill="none" strokeLinecap="round"/>
 <path d="M-95 8Q0-9 95 8" stroke={gold?P.gold:P.mint} strokeWidth="5" fill="none" strokeLinecap="round"/>
 <ellipse cy="90" rx="85" ry="8" fill={P.night} opacity=".18"/>
</g>;

const star=makeStar({points:4,innerRadius:2.2,outerRadius:8,cornerRadius:1}).path;
export const Stars:React.FC<{t:number;opacity?:number}>=({t,opacity=1})=><g opacity={opacity}>{Array.from({length:66},(_,i)=>{
 const x=hash(i+5)*2100-90,y=hash(i+151)*770-70,k=.45+hash(i+301)*.7;
 return <g key={i} transform={`translate(${x} ${y}) scale(${k})`} opacity={.35+Math.sin(t*.8+i)*.25+hash(i)*.25}>{i%5===0?<path d={star} transform="translate(-8 -8)" fill={P.light}/>:<circle r={1.3+hash(i+9)*1.4} fill={P.mint}/>}</g>;
 })}</g>;

export const Fireflies:React.FC<{t:number;count?:number;x?:number;y?:number;w?:number;h?:number;opacity?:number}>=({t,count=12,x=200,y=200,w=1500,h=650,opacity=1})=><g opacity={opacity}>{Array.from({length:count},(_,i)=>{
 const xx=x+hash(i+35)*w+Math.sin(t*.7+i*2)*28,yy=y+hash(i+65)*h+Math.cos(t*.9+i)*18,a=.35+Math.sin(t*2+i*3)*.25;
 return <g key={i} opacity={a}><circle cx={xx} cy={yy} r="15" fill="url(#m-aura)"/><circle cx={xx} cy={yy} r={1.6+hash(i)*1.7} fill={P.light}/></g>;
 })}</g>;

export const Leaf:React.FC<{x:number;y:number;size?:number;angle?:number;flip?:boolean;fill?:string}>=({x,y,size=1,angle=0,flip=false,fill='url(#m-leaf)'})=><g transform={`translate(${x} ${y}) rotate(${angle}) scale(${size*(flip?-1:1)} ${size})`}>
 <path d="M0 0Q-82-77-46-206Q48-182 58-104Q56-40 0 0Z" fill={fill}/>
 <path d="M0-4Q-12-92-39-184" stroke="#53A598" strokeWidth="3" opacity=".25" fill="none"/>
 <path d="M-9-47L-45-84M-16-82L-47-117M-22-115L-45-144M-6-58L34-104M-12-96L27-136" stroke="#68ADA1" strokeWidth="2" opacity=".16"/>
</g>;

export const Plants:React.FC<{t:number;front?:boolean;opacity?:number}>=({t,front=false,opacity=1})=><g opacity={opacity}>
 {[0,1,2,3,4].map(i=><Leaf key={'l'+i} x={-40+i*56} y={1120+i*20} angle={-35+i*22+Math.sin(t*.7+i)*2} size={1.9-i*.12} fill={front?'#071F35':'url(#m-leaf)'}/>)}
 {[0,1,2,3,4].map(i=><Leaf key={'r'+i} x={1940-i*41} y={1130+i*9} angle={-55+i*25+Math.sin(t*.7+i)*2} size={2.1-i*.12} flip fill={front?'#0D1530':'url(#m-leaf)'}/>)}
</g>;

export const Hills:React.FC<{t:number;day?:boolean|number}>=({t,day=false})=>{
 const d=typeof day==='number'?day:day?1:0;
 return <>
 <path d="M-400 720Q-50 330 350 660Q650 330 1060 650Q1360 310 1770 640Q2150 400 2400 700V1500H-400Z" fill={tint('#194F68','#558F92',d)} opacity=".55"/>
 <path d="M-400 850Q100 520 500 730Q900 520 1290 750Q1640 470 2240 780V1500H-400Z" fill={tint('#124855','#286F7C',d)} opacity=".8"/>
 {Array.from({length:26},(_,i)=>{const x=i*94-180,y=690+Math.sin(i*2.1)*42;return <g key={i} fill={tint('#133B4B','#206B68',d)}><path d={`M${x} ${y+140}l5-135h8l11 135Z`}/><ellipse cx={x+10} cy={y} rx={60+hash(i)*15} ry={38+hash(i+7)*20}/><ellipse cx={x-17} cy={y+24} rx="47" ry="30"/></g>;})}
 </>;
};

export const Torch:React.FC<{x:number;y:number;t:number;size?:number}>=({x,y,t,size=1})=><g transform={`translate(${x} ${y}) scale(${size})`}>
 <circle cy="-72" r={220+Math.sin(t*13)*4} fill="url(#m-lamp)"/>
 <path d="M-12 100L-18-48L18-48L12 100Z" fill="#572D4A"/>
 <path d="M-22-47Q-55-91-9-133Q-15-100 16-118Q63-64 22-43Z" fill={P.coral} transform={`skewX(${Math.sin(t*10)*5})`}/>
 <path d="M-16-46Q-34-73 0-105Q3-81 18-86Q39-57 12-44Z" fill={P.gold}/><path d="M-8-48Q-15-67 3-78Q20-59 8-48Z" fill={P.light}/>
</g>;

export const Pyramid:React.FC<{x:number;y:number;size?:number;warm?:boolean;warmLevel?:number}>=({x,y,size=1,warm=false,warmLevel})=>{
 const level=warmLevel??(warm?1:0),c=(a:string,b:string)=>tint(a,b,level);
 return <g transform={`translate(${x} ${y}) scale(${size})`}>
 <ellipse cx="80" cy="10" rx="370" ry="55" fill={P.deep} opacity=".2"/>
 {Array.from({length:6},(_,i)=>{const w=270-i*34,b=-i*49,top=b-49,dep=145-i*11;return <g key={i}>
  <path d={`M${-w} ${b}H${w}L${w-31} ${top}H${-w+31}Z`} fill={c('#32848D','#D29A86')}/>
  <path d={`M${w} ${b}L${w+dep} ${b-dep*.45}L${w-31+dep} ${top-dep*.45}L${w-31} ${top}Z`} fill={c('#235B75','#8D6683')}/>
  <path d={`M${-w+31} ${top}L${-w+31+dep} ${top-dep*.45}H${w-31+dep}L${w-31} ${top}Z`} fill={c('#6BC1AE','#FFD093')}/>
  <path d={`M${-w+5} ${b-8}H${w-5}`} stroke={c('#4F9A98','#EFB88F')} strokeWidth="3"/>
 </g>;})}
 <path d="M-43 0L-19-300H29L65 0Z" fill={c('#91D4B7','#F6BD8D')}/>
 {Array.from({length:24},(_,i)=>{const yy=-i*12.4,w=52-i*.85;return <path key={i} d={`M${-w+10} ${yy}H${w+10}`} stroke={c('#438A8E','#BD8D7C')} strokeWidth="3.5"/>;})}
 <path d="M-72-294V-382H79V-294Z" fill={c('#4A9D9E','#DDA786')}/><path d="M79-294L166-334V-422L79-382Z" fill={c('#215C78','#99768B')}/>
 <path d="M-87-382L5-427H168L79-382Z" fill={c('#80CBB1','#FFD99B')}/>
 <path d="M-25-294V-351L5-370L34-351V-294Z" fill={P.deep}/>
 <path d="M-55-383V-424H-34V-451H-9V-426H14V-457H38V-425H63V-390Z" fill={c('#39929A','#DCA081')}/>
 </g>;
};
