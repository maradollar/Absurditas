import React from 'react';
import {interpolatePath} from '@remotion/paths';
import {P,Zero,Stars,Fireflies,Plants,Leaf,Hills,Torch,span,lerp,camera,s,e,hash} from './art';
import {MayaPerson} from './Person';

export const Temple:React.FC<{t:number}>=({t})=>{
 const close=span(t,.25,1.9)*(1-span(t,2.6,4.5));
 const z=1.18+close*.28,fx=lerp(950,988,close),fy=lerp(620,659,close);
 const rise=span(t,2.65,4.8),zx=lerp(930,1160,rise),zy=lerp(741,510,rise),zs=lerp(.55,1.3,rise);
 return <>
  <rect width="1920" height="1080" fill="url(#m-cave)"/>
  <g transform={camera(z,fx,fy)}>
   <path d="M550 850V100L650 20H1220L1380 150V850Z" fill="url(#m-sky)"/>
   <g opacity=".45"><Stars t={t}/><Hills t={t}/></g>
   <path d="M-500 850Q600 615 1100 806Q1850 690 2500 940V1800H-500Z" fill="url(#m-floor)"/>
   <ellipse cx="1090" cy="870" rx="640" ry="170" fill="url(#m-lamp)"/>
   {/* Corbelled opening and deep walls give foreground/midground separation. */}
   <path d="M100 1300V140H320V40H550V-80H1350V40H1580V140H1820V1300H1570V340H1410V220H1240V145H670V220H505V340H350V1300Z" fill="#2F2549"/>
   <path d="M100 1300V140H320V40H550V-80H620V98H410V200H210V1300Z" fill="#25334D"/>
   <path d="M1570 340H1410V220H1240V145H670V220H505V340H350V1300H420V397H575V280H731V200H1190V280H1355V397H1505V1300H1570Z" fill="#583250" opacity=".7"/>
   <path d="M630 170L1070 150L1520 1230L850 1150Z" fill={P.gold} opacity=".035"/>
   <path d="M-40 455L341 413V483L-40 525M1570 570L2050 628V697L1570 640" fill="#4D2E53"/>
   <path d="M174 318h88m-88 28h88m-50-56v85M1640 402h83m-83 28h83m-50-56v85" stroke="#6D3C66" strokeWidth="8" opacity=".35"/>
   <Torch x={1440} y={485} t={t} size={1.1}/><Torch x={370} y={590} t={t+.7} size={.75}/>
   <path d="M1125 925L1120 1150L1180 1160L1190 920M1400 785L1385 1030L1435 1030L1460 780" fill="#22465B"/>
   <path d="M870 760L1150 660L1450 770L1120 940Z" fill="url(#m-stone)"/>
   <path d="M870 760L1120 940L1450 770V830L1120 1000L870 817Z" fill="#24566B"/>
   <path d="M1120 940V1000L1450 830V770Z" fill="#194A62"/>
   <path d="M884 758L1120 916L1422 772" stroke="#92C5A9" strokeWidth="4" fill="none" opacity=".4"/>
   <g transform="translate(1225 752) rotate(-9)"><path d="M-72-32L-4-52L76-20L18 22Z" fill={P.cream}/><path d="M-61-27L17 12M-35-34L40 2M-9-39L62-9" stroke="#C39D87" strokeWidth="3"/></g>
   <g transform="translate(1510 903)"><path d="M-53-29Q-65-94-20-117H20Q65-94 53-29Q40 10 0 12Q-40 10-53-29Z" fill="#A65965"/><ellipse cy="-113" rx="22" ry="8" fill="#6A315A"/><path d="M-51-48q48 15 102 0" stroke={P.gold} strokeWidth="8" fill="none"/></g>
   <MayaPerson x={790} y={952} t={t} size={1.4} pose="write" color={P.jade}/>
   <Zero x={930} y={741} size={.55} t={t} opacity={rise*.1} glow={false} gold={false}/>
   <Zero x={zx} y={zy} size={zs} t={t} gold/>
   <g opacity={span(t,2.3,3.2)}>{Array.from({length:16},(_,i)=>{const a=i/16*Math.PI*2+t*.25,rx=160+rise*65,ry=78+rise*65;return <circle key={i} cx={zx+Math.cos(a)*rx} cy={zy+Math.sin(a)*ry} r={1.5+hash(i)*2} fill={P.gold} opacity={.3+hash(i)*.4}/>;})}</g>
   <Fireflies t={t} count={16} x={430} y={260} w={1200} h={600}/>
  </g>
  <g transform={`translate(${-close*25} 0)`}><Plants t={t} front/></g>
  <path d="M-50-100H240L200 1080H-50ZM1745-100H2000V1200H1820Z" fill={P.night} opacity=".52"/>
 </>;
};

const dotPath='M-44 0C-44-24-24-44 0-44C24-44 44-24 44 0C44 24 24 44 0 44C-24 44-44 24-44 0Z';
const barPath='M-205 0C-205-23-185-28-165-28H165C185-28 205-23 205 0C205 23 185 28 165 28H-165C-185 28-205 23-205 0Z';

export const Numbers:React.FC<{t:number}>=({t})=>{
 const u=t-4.7,spread=span(t,5.9,6.6),merge=span(t,6.65,7.55),stack=span(t,8.1,10.7),out=span(t,12.7,14.3);
 const cx=lerp(940,960,stack),cy=lerp(535,490,stack),z=lerp(1.28,.91,stack);
 const fly=span(t,4.95,5.55);
 const main=interpolatePath(merge,dotPath,barPath);
 return <>
  <rect width="1920" height="1080" fill="url(#m-sky)"/>
  <circle cx="950" cy="520" r="690" fill="url(#m-jade-aura)" opacity=".25"/>
  <g opacity=".1" fill="none" stroke={P.jade} strokeWidth="2"><ellipse cx="960" cy="610" rx="760" ry="260"/><ellipse cx="960" cy="610" rx="530" ry="405"/></g>
  <Stars t={t} opacity={.6}/>
  <g transform={camera(z,960,540)}>
   <g opacity={stack} transform={`translate(0 ${(1-stack)*600})`}>
    <path d="M692 900L722 146L1180 131L1210 896Z" fill="#20576C"/>
    <path d="M722 146L799 94L1241 90L1180 131Z" fill="#4A9B9A"/><path d="M1180 131L1241 90L1270 845L1210 896Z" fill="#163D55"/>
    <path d="M747 170L1158 155M721 899L1188 893" stroke="#75C5B3" strokeWidth="4" opacity=".55"/>
    <path d="M725 352H1190M718 637H1200" stroke="#3D7A83" strokeWidth="3"/>
   </g>
   <g transform={`translate(${cx} ${cy})`} opacity={span(t,5.25,5.58)}>
    <ellipse rx="310" ry="180" fill="url(#m-aura)" opacity={1-stack*.5}/>
    {[-2,-1,1,2].map((i)=><circle key={i} cx={i*105*spread*(1-merge)} cy={Math.sin(i+u)*15*spread*(1-merge)} r={44*(1-merge*.9)} opacity={span(t,5.85,6.4)*(1-merge)} fill={P.gold}/>)}
    <path d={main} fill="url(#m-gold)"/>
    <path d={main} fill="none" stroke={P.light} strokeWidth="2.5" opacity=".5"/>
   </g>
   {fly>0&&fly<1&&<circle cx={lerp(580,940,fly)} cy={lerp(747,535,fly)-Math.sin(fly*Math.PI)*85} r={lerp(8,44,fly)} fill={P.gold}/>}
   <g opacity={1-span(t,6.1,7.0)}><Zero x={lerp(1160,1550,span(t,4.7,5.7))} y={510} size={lerp(1.3,.72,span(t,4.7,5.7))} t={t}/></g>
   {/* One point, one bar and a zero occupy vertically arranged place values. */}
   <g opacity={span(t,8.65,9.4)} transform={`translate(0 ${(1-stack)*140})`}>
    <Zero x={960} y={790} size={.82} t={t} gold={false}/>
    <circle cx={lerp(960,1498,out)} cy={lerp(490,215,span(t,9.3,10.7))+out*60} r={lerp(44,110,out)} fill={P.gold}/>
   </g>
   {[-1,1].map(side=><g key={side} opacity={stack*.38} fill="none" strokeWidth="4" stroke={P.jade}>
    <path d={`M${960+side*310} 845V225Q${960+side*310} 180 ${960+side*235} 180`} strokeDasharray="2 16"/>
    {[215,490,790].map(yy=><path key={yy} d={`M${960+side*300} ${yy}h${side*34}`}/>)}
   </g>)}
   <g opacity={stack*.5}><ellipse cx="960" cy="911" rx="320" ry="45" fill="#0A283E"/><ellipse cx="960" cy="897" rx="330" ry="44" fill="none" stroke={P.jade} strokeWidth="2"/></g>
   <path d="M170 1040Q450 890 675 1010L730 1140H170Z" fill="#15465B"/>
   <MayaPerson x={470} y={995} size={1.1} t={t} pose="count" color={P.jade}/>
   <path d="M584 744Q655 550 902 539" stroke={P.jade} strokeWidth="2" strokeDasharray="2 12" fill="none" opacity={.35*(1-stack)}/>
   {Array.from({length:24},(_,i)=>{const q=span(t,8.7+i*.035,11.0+i*.035),a=i/24*Math.PI*2+t*.08;return <circle key={i} cx={960+Math.cos(a)*(220+q*420)} cy={550+Math.sin(a)*(70+q*340)} r={2+hash(i+1)*3} fill={i%3?P.jade:P.gold} opacity={q*.45*(1-out)}/>;})}
  </g>
  <path d="M-100 1080Q400 1000 720 1080ZM1330 1080Q1640 970 2030 1080Z" fill={P.night} opacity=".75"/>
  <Leaf x={10} y={1130} size={2.2} angle={23} fill="#102B42"/><Leaf x={1910} y={1140} size={2.7} angle={-12} flip fill="#102B42"/>
  <Fireflies t={t} count={18} opacity={.65}/>
 </>;
};
