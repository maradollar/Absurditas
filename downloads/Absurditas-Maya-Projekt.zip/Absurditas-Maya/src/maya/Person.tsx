import React from 'react';
import {P,lerp,s,span} from './art';

type V=[number,number];
const joint=(a:V,b:V,l1:number,l2:number,side=1):V=>{
 const dx=b[0]-a[0],dy=b[1]-a[1],actual=Math.hypot(dx,dy),d=Math.max(.01,Math.min(actual,l1+l2-.01));
 const along=(l1*l1-l2*l2+d*d)/(2*d),h=Math.sqrt(Math.max(0,l1*l1-along*along)),ux=dx/Math.max(actual,.01),uy=dy/Math.max(actual,.01);
 return [a[0]+ux*along-uy*h*side,a[1]+uy*along+ux*h*side];
};
export type MayaPersonProps={x:number;y:number;t:number;size?:number;dir?:number;pose?:'write'|'hold'|'walk'|'look'|'greet'|'carry'|'count';travel?:number;modern?:boolean;child?:boolean;female?:boolean;seed?:number;color?:string};

export const MayaPerson:React.FC<MayaPersonProps>=({x,y,t,size=1,dir=1,pose='hold',travel=0,modern=false,child=false,female=false,seed=0,color=P.jade})=>{
 const walk=pose==='walk'||(pose==='carry'&&Math.abs(travel)>.001),breath=Math.sin(t*1.7+seed)*.65,phase=travel/size/110;
 const blink=[2.2,6.9,12.6,20.2,25.8,29.1].some(q=>t+seed*.21>q&&t+seed*.21<q+.105);
 const tilt=pose==='look'?-12*span(t,18.5,20):pose==='write'?2+Math.sin(t*.8)*1.4:Math.sin(t*.9+seed)*1.2;
 const skin=seed%3===0?'url(#m-skin)':seed%3===1?'#B86E51':'#D89165';
 let lh:V=[-45,-127],rh:V=[48,-129];
 if(pose==='write'){lh=[-47,-130];rh=[83+Math.cos(t*2.7)*14,-130+Math.sin(t*2.7)*8];}
 if(walk){lh=[-46-Math.sin(phase*Math.PI*2)*22,-140-Math.cos(phase*Math.PI*2)*10];rh=[46+Math.sin(phase*Math.PI*2)*22,-140+Math.cos(phase*Math.PI*2)*10];}
 if(pose==='carry'){lh=[-41,-144];rh=[48,-146];}
 if(pose==='hold'){lh=[-44,-134];rh=[66,-128];}
 if(pose==='look'){lh=[-40,-132];const q=span(t,18.1,19.4);rh=[lerp(48,75,q),lerp(-135,-260,q)];}
 if(pose==='greet'){lh=[-47,-125];const q=span(t,24,25);rh=[lerp(49,65,q)+Math.sin(t*5)*7*q,lerp(-129,-247,q)];}
 if(pose==='count'){lh=[-48,-132];const q=span(t,4.9,5.6);rh=[lerp(48,100,q)+Math.sin(t*.8)*6,lerp(-129,-226,q)+Math.cos(t*.7)*9];}
 const arm=(a:V,b:V,back=false)=>{
  const mid=joint(a,b,55,51,back?-1:1),sleeve=modern?color:'url(#m-tunic)';
  return <g>
   <path d={`M${a}Q${mid} ${b}`} stroke={skin} strokeWidth="23" strokeLinecap="round" fill="none"/>
   <path d={`M${a}L${lerp(a[0],mid[0],.7)} ${lerp(a[1],mid[1],.7)}`} stroke={sleeve} strokeWidth="32" strokeLinecap="round" fill="none"/>
   <ellipse cx={b[0]} cy={b[1]} rx="12" ry="10" fill={skin}/>
   {(pose==='greet'||pose==='look'||pose==='count')&&!back?<path d={`M${b[0]-7} ${b[1]}v-17q3-7 7 0v9l5-13q4-5 5 1l-2 14 7-8q5-3 5 3l-10 15Z`} fill={skin}/>:null}
  </g>;
 };
 const leg=(i:number)=>{
  let foot:V=[i?22:-18,0];
  if(walk){const ph=((phase+(i?.5:0))%1+1)%1;if(ph<.62){foot=[34-110*ph,0];}else{const u=(ph-.62)/.38;foot=[-34.2+68.2*s(u),-Math.sin(u*Math.PI)*26];}}
  const hip:V=[i?17:-17,-110],knee=joint(hip,foot,56,56,walk?-1:i?-1:1);
  return <g>
   <path d={`M${hip}L${knee}L${foot[0]} ${foot[1]-6}`} stroke={modern?(i?'#3B4273':'#30335A'):skin} strokeWidth="25" strokeLinecap="round" fill="none"/>
   <path d={`M${foot[0]-10} ${foot[1]-9}Q${foot[0]+12} ${foot[1]-14} ${foot[0]+24} ${foot[1]-1}Q${foot[0]+24} ${foot[1]+5} ${foot[0]-12} ${foot[1]+3}Z`} fill={modern?P.cream:'#363149'}/>
   {!modern&&<path d={`M${foot[0]-9} ${foot[1]-6}l16 1`} stroke="#725453" strokeWidth="7"/>}
  </g>;
 };
 return <g transform={`translate(${x} ${y}) scale(${size*dir} ${size})`}>
  <ellipse cy="6" rx="54" ry="11" fill={P.deep} opacity=".18"/>
  {leg(0)}{leg(1)}
  <g transform={`translate(0 ${breath-(walk?Math.abs(Math.sin(phase*Math.PI*2))*3:0)})`}>
   {arm([-35,-190],lh,true)}
   <path d="M-36-207Q3-216 38-200L44-121Q10-98-43-123Z" fill={modern?color:'url(#m-tunic)'}/>
   <path d="M-29-207Q-13-184 20-197L22-214Z" fill={skin}/>
   {!modern&&<>
    <path d="M-39-132Q8-120 43-134L49-91Q0-76-47-91Z" fill={color}/>
    <path d="M-42-125Q3-114 44-126L46-112Q4-101-43-112Z" fill={P.coral}/>
    <path d="M-32-203L-18-205L32-122L15-117Z" fill={color}/>
    <path d="M-38-101h13m9 3h13m9-1h11" stroke={P.gold} strokeWidth="4"/>
   </>}
   {modern&&female&&<path d="M-42-123Q0-109 43-123L57-59Q10-43-60-58Z" fill="#5D4176"/>}
   <path d="M-13-229V-204Q0-192 18-204V-229Z" fill={skin}/>
   <g transform={`rotate(${tilt} 0 -257) scale(${child?1.09:1})`}>
    <path d="M-37-267Q-35-304-3-308Q30-310 43-281L43-259L53-245Q54-240 42-238Q32-215 5-217Q-28-220-32-247Z" fill={skin}/>
    <path d="M24-285Q48-270 42-256L51-246L38-240L33-224Q16-214 5-219Q27-227 25-250Z" fill="#A75D55" opacity=".42"/>
    <path d="M-33-257Q-53-263-48-247Q-44-237-31-239Z" fill={skin}/>
    <path d="M-36-262Q-44-280-24-304Q-2-323 30-305L45-283Q14-279-9-293L-22-271L-24-244L-36-242Z" fill={P.hair}/>
    {female?<><path d="M-26-294Q-70-302-60-273Q-55-254-30-262Z" fill={P.hair}/><path d="M-36-260q-18 32-2 55" fill="none" stroke={P.hair} strokeWidth="15"/></>:<path d="M-19-307Q-36-329-15-339Q15-346 23-327L13-309Z" fill={P.hair}/>}
    {!modern&&<path d="M-36-285Q1-295 38-284" fill="none" stroke={color} strokeWidth="9"/>}
    <path d="M-3-267q8-5 15-1m12-2 10 3" stroke={P.hair} strokeWidth="4" strokeLinecap="round" fill="none"/>
    {!blink?<><ellipse cx="6" cy="-256" rx="4.2" ry="6.8" fill={P.night}/><ellipse cx="30" cy="-257" rx="3.4" ry="6.2" fill={P.night}/><circle cx="7" cy="-258" r="1.5" fill={P.cream}/><circle cx="31" cy="-259" r="1.2" fill={P.cream}/></>:<path d="M1-255h10m15-1h7" stroke={P.night} strokeWidth="3" strokeLinecap="round"/>}
    <path d="M12-230q10 5 19-2" fill="none" stroke="#87454E" strokeWidth="3" strokeLinecap="round"/>
    <ellipse cx="18" cy="-242" rx="9" ry="4" fill={P.coral} opacity=".22"/>
    {!modern&&<circle cx="-35" cy="-240" r="7" fill={P.gold}/>} 
   </g>
   {pose==='carry'&&<g transform="translate(0 -139)"><path d="M-50-14Q0-27 53-14L42 27Q0 42-43 27Z" fill="#BF8068"/><ellipse cy="-15" rx="52" ry="16" fill="#E6AE79"/><path d="M-34-6l3 28m16-27 1 31m17-30v30m18-32-2 30m17-36-4 32" stroke="#94616A" strokeWidth="3"/>{[-28,-5,22].map((xx,i)=><ellipse key={xx} cx={xx} cy={-26-i%2*9} rx="11" ry="23" fill={i%2?P.coral:P.gold} transform={`rotate(${i*10-10} ${xx} -25)`}/>)}</g>}
   {pose==='hold'&&<><path d="M-38-157L56-163L61-112L-35-102Z" fill={modern?'#253356':P.cream}/>{modern&&<><path d="M-28-150L45-155L49-123L-27-114Z" fill="#56B9BC"/><circle cx="-10" cy="-136" r="4" fill={P.cream}/><path d="M2-140h29v4H2Zm-20 13h43v3h-43Z" fill={P.cream}/></>}</>}
   {arm([34,-193],rh)}
   {pose==='write'&&<path d={`M${rh[0]-6} ${rh[1]+8}L${rh[0]+17} ${rh[1]-21}`} stroke={P.gold} strokeWidth="5" strokeLinecap="round"/>}
  </g>
 </g>;
};
