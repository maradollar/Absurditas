export const narration = [
  {
    "sentence": 1,
    "start": 0.18,
    "end": 2.234965986394558,
    "text": "Dieses Zeichen sieht aus wie eine Muschel."
  },
  {
    "sentence": 2,
    "start": 2.714965986394558,
    "end": 4.6334693877551025,
    "text": "Für die Maya bedeutete es: null."
  },
  {
    "sentence": 3,
    "start": 5.313469387755102,
    "end": 7.974648526077098,
    "text": "Ein Punkt stand für eins, ein Balken für fünf."
  },
  {
    "sentence": 4,
    "start": 8.454648526077097,
    "end": 12.972154195011338,
    "text": "Aber der eigentliche Trick war die Anordnung: Zahlen über Zahlen, wie Stockwerke."
  },
  {
    "sentence": 5,
    "start": 13.752154195011338,
    "end": 16.59659863945578,
    "text": "So konnten sie auch riesige Zeiträume festhalten."
  },
  {
    "sentence": 6,
    "start": 17.11659863945578,
    "end": 21.464897959183673,
    "text": "Sie bauten große Städte, entwickelten eine Schrift und beobachteten die Sterne."
  },
  {
    "sentence": 7,
    "start": 22.184897959183672,
    "end": 24.669433106575962,
    "text": "Und diese Geschichte ist nicht einfach verschwunden."
  },
  {
    "sentence": 8,
    "start": 25.009433106575962,
    "end": 26.460680272108842,
    "text": "Maya leben bis heute."
  }
] as const;
