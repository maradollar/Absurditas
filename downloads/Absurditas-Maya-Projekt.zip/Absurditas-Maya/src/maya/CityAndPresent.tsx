import React from 'react';
import {P,Pyramid,Stars,Fireflies,Plants,Leaf,Hills,Zero,camera,span,lerp,hash,tint} from './art';
import {MayaPerson} from './Person';

const House:React.FC<{x:number;y:number;size?:number;modern?:boolean;warm?:boolean;warmLevel?:number}>=({x,y,size=1,modern=false,warm=false,warmLevel})=>{
 const level=warmLevel??(warm?1:0),c=(a:string,b:string)=>tint(a,b,level);
 return <g transform={`translate(${x} ${y}) scale(${size})`}>
 <ellipse cx="35" cy="4" rx="145" ry="22" fill={P.deep} opacity=".18"/>
 <path d="M-95 0V-115L85-127V-5Z" fill={c('#9DCDBA','#EAB98F')}/><path d="M85-5L150-45V-165L85-127Z" fill={c('#52989D','#AD7D85')}/>
 {modern?<><path d="M-109-118L-40-194L167-174L89-119Z" fill="#B56677"/><path d="M89-119L167-174L167-156L89-101Z" fill="#784D75"/><path d="M-97-119L-40-182L-40-159L-80-118Z" fill={P.coral}/></>:<><path d="M-113-116L-47-204L167-177L91-114Z" fill={c('#9AB49C','#EEBC78')}/><path d="M91-114L167-177L167-157L91-94Z" fill="#567F86"/>{Array.from({length:9},(_,i)=><path key={i} d={`M${-35+i*22}-194l-55 72`} stroke={c('#75968A','#D29C71')} strokeWidth="3"/> )}</>}
 <path d="M-20 0V-82Q3-95 25-82V-2Z" fill={P.deep}/><path d="M48-64V-100L71-101V-65Z" fill={c('#338A90','#95697D')}/>
 <path d="M-83-20L-39-21M38-22L75-24" stroke={c('#79B4AC','#CE9D88')} strokeWidth="3"/>
 </g>;
};

export const City:React.FC<{t:number}>=({t})=>{
 const day=span(t,13.8,16.25),night=span(t,19.0,21.25),pan=span(t,17.1,21.7);
 const z=lerp(.86,1.21,span(t,16.1,18.7)),fx=lerp(1030,1820,pan),fy=lerp(625,672,pan);
 const sunX=lerp(1450,1455,day),sunY=lerp(300,380,day),orb=span(t,13.45,16.6);
 return <>
  <rect width="1920" height="1080" fill="url(#m-sky)"/>
  <rect width="1920" height="1080" fill="url(#m-dawn)" opacity={day*(1-night*.9)}/>
  <circle cx={sunX} cy={sunY} r="260" fill="url(#m-aura)" opacity={1-night*.7}/>
  <circle cx={sunX} cy={sunY} r={110-day*18} fill={P.light} opacity={Math.pow(1-night,3)}/>
  <defs><mask id="m-moon-mask" maskUnits="userSpaceOnUse" x="1350" y="130" width="240" height="220"><rect x="1350" y="130" width="240" height="220" fill="black"/><circle cx="1455" cy="230" r="66" fill="white"/><circle cx="1481" cy="209" r="64" fill="black"/></mask></defs>
  <g opacity={night}><circle cx="1455" cy="230" r="66" fill={P.mint} mask="url(#m-moon-mask)"/><Stars t={t}/></g>
  <g opacity={(1-day)*.5}><Stars t={t}/></g>
  <g opacity={(1-span(t,16.0,17.0))*.65} transform={`translate(${sunX} ${sunY}) rotate(${orb*80})`}>
   <circle r="157" fill="none" stroke={P.gold} strokeWidth="2" strokeDasharray="2 16"/>
   {Array.from({length:20},(_,i)=>{const a=i/20*Math.PI*2;return <path key={i} d={`M${Math.cos(a)*139} ${Math.sin(a)*139}L${Math.cos(a)*149} ${Math.sin(a)*149}`} stroke={P.gold} strokeWidth={i%5===0?5:2}/>;})}
   <circle cx={Math.cos(orb*Math.PI*1.8)*157} cy={Math.sin(orb*Math.PI*1.8)*157} r="10" fill={P.jade}/>
  </g>
  <g transform={`translate(${-pan*72} 0)`}><Hills t={t} day={day*(1-night)}/></g>
  <g transform={camera(z,fx,fy)}>
   <path d="M-700 1050Q500 550 1400 794Q2230 640 3400 1070V1800H-700Z" fill={tint('#74A99A','#215F6C',night)}/>
   <path d="M-700 1260Q900 700 1800 900Q2700 840 3400 1210V1900H-700Z" fill={tint('#4B8D89','#25516B',night)}/>
   <path d="M-500 1240Q900 930 1540 1110Q2020 1280 2400 1100Q2940 880 3400 1160" fill="none" stroke="url(#m-water)" strokeWidth="118"/>
   <path d="M-500 1224Q900 914 1540 1094Q2020 1264 2400 1084Q2940 864 3400 1144" fill="none" stroke={P.mint} strokeWidth="5" opacity=".28"/>
   {[[-100,836,.75],[210,820,.6],[1440,790,.6],[1880,797,.8],[2400,855,.7],[2780,910,.9]].map(([x,y,size],i)=><House key={i} x={x} y={y} size={size} warmLevel={day*(1-night)}/>)}
   <Pyramid x={845} y={956} size={1.25} warmLevel={day*(1-night)}/>
   <Pyramid x={430} y={766} size={.38}/>
   <path d="M-300 1160Q1000 870 1600 1010L1800 1100Q1000 990-300 1310Z" fill={tint('#CFB28F','#6D6A7B',night)} opacity=".85"/>
   <path d="M2120 925L2440 830L2590 920L2250 1030Z" fill="#7EAFA5"/><path d="M2120 925L2250 1030V1078L2120 974Z" fill="#3F7887"/><path d="M2250 1030L2590 920V969L2250 1078Z" fill="#285B75"/>
   <MayaPerson x={1330+(t-13.4)*9} y={1025} size={.67} t={t} pose="walk" travel={(t-13.4)*9} color={P.coral} seed={3}/>
   <MayaPerson x={1990-(t-13.4)*6} y={899} size={.51} t={t} dir={-1} pose="carry" travel={(t-13.4)*6} color={P.jade} seed={1}/>
   {/* A foreground scribe is framed by the moving camera as the voice mentions writing. */}
   <path d="M1710 927L1695 1110L1742 1110L1758 931M1910 842L1900 1045L1950 1030L1966 842" fill="#265264"/>
   <path d="M1650 856L1830 782L2000 847L1776 965Z" fill="#82C1AE"/><path d="M1650 856V898L1776 1006L2000 889V847L1776 965Z" fill="#296677"/>
   <MayaPerson x={1580} y={1065} size={1.18} t={t} pose="write" color={P.coral} seed={0}/>
   <g transform={`translate(1763 868) rotate(-12)`}>
    <path d="M-70-20Q-24-45 0-25Q38-51 84-25L75 30Q35 17 0 42Q-34 22-72 36Z" fill={P.cream}/>
    <path d="M0-23V40" stroke="#D7A189" strokeWidth="4"/>
    {[0,1,2,3].map(i=><g key={i} fill="#6F5665"><circle cx={-51+i*14} cy={-8+(i%2)*6} r="3"/><path d={`M${-50+i*12} 14h9v3h-9Z`}/></g>)}
    <Zero x={41} y={3} size={.17} glow={false} gold={false}/>
   </g>
   <MayaPerson x={2270} y={947} size={.87} t={t} pose="look" female color={P.jade} seed={2}/>
   <path d="M2380 860L2394 655M2260 860L2380 648" stroke="#D3B98A" strokeWidth="8" strokeLinecap="round"/><path d="M2365 673L2389 657L2405 668" fill="none" stroke={P.gold} strokeWidth="5"/>
   {[250,1470,2680].map((xx,i)=><g key={xx}><path d={`M${xx} 1020q-10-180 35-270`} fill="none" stroke="#245364" strokeWidth="22"/>{[-45,0,40].map((a,j)=><Leaf key={a} x={xx+25} y={770} size={.8+j*.15} angle={a} fill={i%2?'#337F7C':'#2B6B78'}/> )}</g>)}
  </g>
  <g transform={`translate(${-pan*58} 0)`}><Plants t={t}/></g>
  <Fireflies t={t} count={15} opacity={.35+night*.5}/>
 </>;
};

export const Present:React.FC<{t:number}>=({t})=>{
 const u=t-23.0,drift=span(t,23,29.7),z=lerp(1.13,1.02,drift);
 return <>
  <rect width="1920" height="1080" fill="url(#m-sky)"/>
  <rect width="1920" height="1080" fill="url(#m-dawn)" opacity=".42"/>
  <circle cx="1440" cy="245" r="230" fill="url(#m-aura)"/><circle cx="1440" cy="245" r="77" fill={P.light}/>
  <g opacity=".2"><Stars t={t}/></g><Hills t={t} day/>
  <g transform={camera(z,lerp(970,1030,drift),615)}>
   <Pyramid x={1420} y={768} size={.61} warm/>
   <path d="M-600 1100Q950 700 2500 1040V1800H-600Z" fill="#4A9292"/>
   <path d="M-500 1200Q1100 745 2450 1080V1800H-500Z" fill="#397D86"/>
   <path d="M-300 1030Q920 890 2200 1070L2450 1200Q900 1000-300 1190Z" fill="#AA9C94"/>
   <House x={205} y={921} size={1.65} modern warm/>
   <House x={1850} y={934} size={1.57} modern warm/>
   <House x={1640} y={854} size={.73} modern/>
   <path d="M-100 800Q160 430 380 784Q560 520 740 778" stroke="#233C5A" strokeWidth="3" fill="none" opacity=".4"/>
   <g transform="translate(1320 1120)"><path d="M-180-40L150-94L201-40L-127 20Z" fill="#57A19D"/><path d="M-127 20V74L201 9V-40Z" fill="#205A71"/><Zero x={28} y={-42} size={.24} glow={false}/></g>
   <MayaPerson x={835} y={1020} size={1.18} t={t} modern female pose="hold" color={P.coral} seed={2}/>
   <MayaPerson x={1130} y={1062} size={.75} t={t} modern child pose="greet" color={P.jade} seed={0}/>
   <MayaPerson x={1480+(t-23)*24} y={928} size={.68} t={t} modern pose="walk" travel={(t-23)*24} color="#EAB560" seed={1}/>
   <MayaPerson x={470-(t-23)*11} y={969} size={.76} t={t} modern pose="carry" travel={(t-23)*11} dir={-1} color="#6DC3B8" seed={1}/>
   {[-50,490,1750,2090].map((xx,i)=><g key={i}><path d={`M${xx} 1080q-50-230-15-395`} stroke="#2A5869" strokeWidth="24" fill="none"/>{[-58,-20,24,64].map((a,j)=><Leaf key={a} x={xx-12} y={733} size={.85+j*.16} angle={a} fill={i%2?'#1E6571':'#2A7B7D'}/> )}</g>)}
  </g>
  <Plants t={t}/><Fireflies t={t} count={13} opacity={.45}/>
  <g opacity={span(t,28.0,29.0)} transform="translate(1170 1010)">
   <circle cx="-36" cy="-13" r="23" fill={P.coral}/><text x="-36" y="-4" textAnchor="middle" fill={P.cream} fontFamily="Display" fontSize="25">A</text>
   <text x="3" y="-4" fill={P.cream} fontFamily="Display" fontSize="26" letterSpacing="4">ABSURDITAS</text>
  </g>
 </>;
};
