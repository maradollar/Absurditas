import React from 'react';
import {Composition} from 'remotion';
import {MayaFilm} from './MayaFilm';
export const Root: React.FC=()=> <Composition id="Maya" component={MayaFilm} width={1920} height={1080} fps={30} durationInFrames={900}/>;
